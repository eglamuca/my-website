<?php
	$redirect_url = "";
	if (isset($redirect_url) && (strlen($redirect_url) > 0)) {
		header("HTTP/1.1 301 Moved Permanently");
		header("Location: $redirect_url");
		header("Connection: close");
		exit(0);
	}

	$index_html = dirname(__FILE__) . "/index.html";
	if (file_exists($index_html)) { require $index_html; exit(0); }
	
	$page_title = "Welcome";
	if (defined("BASE_HOST_NAME_LOWER")) { $page_title = "Welcome | " . BASE_HOST_NAME_LOWER; }
?>
<html><head><title><?php echo $page_title; ?></title><meta name="robots" content="noindex,nofollow"></head><body></body></html>
