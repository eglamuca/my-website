<?php
	$redirect_url = "";
	if (isset($redirect_url) && (strlen($redirect_url) > 0)) {
		header("HTTP/1.1 301 Moved Permanently");
		header("Location: $redirect_url");
		header("Connection: close");
		exit(0);
	}

	$error_404_html = dirname(__FILE__) . "/404.html";
	if (file_exists($error_404_html)) { require $error_404_html; exit(0); }
	
	$page_title = "404 Not Found";
	if (defined("BASE_HOST_NAME_LOWER")) { $page_title = "404 Not Found | " . BASE_HOST_NAME_LOWER; }
?>
<html><head><title><?php echo $page_title; ?></title><meta name="robots" content="noindex,nofollow"></head><body><h1>Page Not Found</h1><p>HTTP Error 404.</p></body></html>
