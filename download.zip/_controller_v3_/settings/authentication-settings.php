<?php
/**
 * 2025-03-26 created
 */

	// Central authentication validation endpoint
	define('CENTRAL_AUTHENTICATION_VALIDATOR_ENDPOINT_URL', 'https://zomdak.com/central-auth-token/');

	// Optional: allow IPv4/IPv6 mismatch between the central auth and this site
	// In some setups, this site may receive IPv4 while central auth saw IPv6 (e.g. no AAAA DNS record for this site).
	define('AUTHENTICATION_ALLOW_IP_MISMATCH', false);

	// Log file for authentication-related errors
	define('AUTHENTICATION_ERRORS_LOG_FILE_FULLNAME', CONTROLLER_LOGS_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'authentication-errors-log.txt');

	// Directories for pending and active authentication sessions
	define('AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME', CONTROLLER_TEMP_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'auth-pending-sessions');
	define('AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME',  CONTROLLER_TEMP_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'auth-active-sessions');
	
	// Time window in which a session must be activated after being initialized (in seconds)
	define('AUTHENTICATION_MAX_TIME_WINDOW_FOR_ACTIVATION_SEC', 1);
	
	// Duration of the authentication cookie in seconds (12 hours)
	define('AUTHENTICATION_SESSIONS_COOKIE_DURATION_SEC', 43200); // 12 Hours

?>