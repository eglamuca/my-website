<?php
/**
 * 2025-03-26 Added support for authentication restricted URLs and authentication restricted parameters
 * 2025-03-26 Added support for IP restricted parameters
 * 2025-03-23 Added support for restricting resource names to allowed IPs only
 * 2024-09-09 Clear cache added
 * 2023-04-27 Major merge of latest changes
 * 2020-07-20 Version 3.0 created
 * 2013-10-23 Version 2.0 created
 */
 
	/**
	 * Request validation settings
	 */
	define('CONTROLLER_ALLOW_HTTP_USER_AGENT_NOT_SET', false);	// usually a request without HTTP_USER_AGENT is not a valid request, but there might be situations where we want to allow such requests
	
	/**
	 * Log settings
	 */
	define('CONTROLLER_LOG_REQUESTS', true);
	define('CONTROLLER_LOG_FILES_DATE_PREFIX', gmdate('Ymd--'));
	define('CONTROLLER_REQUESTS_LOG_FILE_FULLNAME',        CONTROLLER_LOGS_DIR_FULLNAME . DIRECTORY_SEPARATOR . CONTROLLER_LOG_FILES_DATE_PREFIX . 'requests-log.txt');
	define('CONTROLLER_RESPONSE_ERRORS_LOG_FILE_FULLNAME', CONTROLLER_LOGS_DIR_FULLNAME . DIRECTORY_SEPARATOR . CONTROLLER_LOG_FILES_DATE_PREFIX . 'response-errors-log.txt');
	
	/**
	 * Fix SSL settings issues
	 */
	define('FORCE_SSL_ADMIN', true);
	if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && (false !== strpos($_SERVER['HTTP_X_FORWARDED_PROTO'], 'https'))) { $_SERVER['HTTPS']='on'; }

	/**
	 * Settings for the controller
	 */
	class ControllerSettings {
		
		/**
		 * Array of URLs that are not allowed for access
		 *
		 * NOTES:
		 * - URL must begin with '/'
		 * - all sub-paths under a forbidden URL are also forbidden
		 *
		 * Examples:
		 *   setting the following URLs as forbidden: '/foo/', '/la.php' will not allow the following requests:
		 *     http://mysite.com/foo
		 *     http://mysite.com/foo/
		 *     http://mysite.com/foo/loo
		 *     http://mysite.com/la.php
		 *     http://mysite.com/la.php?r=9
		 *     http://mysite.com/la.php/bu
		 *   while these request are not forbidden:
		 *     http://mysite.com/foofoo
		 *     http://mysite.com/la.phppp
		 */
		public static function getForbiddenUrlsArray() {
			return [
				
				// '/put/your/url/here/',
				
				'/_controller_v3_/main.php',
				'/_controller_v3_/core',
				'/_controller_v3_/settings',
				'/_controller_v3_/templates',

			];
		}
		
		/**
		 * Array of URLs allowed only from specific IPs
		 *
		 * NOTES:
		 * - each URL must start with '/'
		 * - all sub-paths under an IP-restricted URL are also IP-restricted
		 */
		public static function getIpRestrictedUrlsArray() {
			return [
				
				// '/put/your/url/here/',

				'/_controller_v3_/',
				'/_shift_/',

				'/wp-admin/',
				'/wp-login.php',
				'/xmlrpc.php',

			];
		}

		/**
		 * Array of resource names (file names) allowed only from specific IPs
		 *
		 * NOTES:
		 * - file names only (no paths)
		 * - restriction applies anywhere in the URL
		 */
		public static function getIpRestrictedResourceNamesArray() {
			return [

				'__black__index.php',

			];
		}

		/**
		 * Array of GET parameters allowed only from specific IPs
		 *
		 * If the client IP is not in the allowed IPs list, these parameters are removed from $_GET, an error is logged,
		 * and the request is processed as if these parameters were never present.
		 *
		 * NOTES:
		 * The controller intentionally does not modify $_REQUEST or $_SERVER['QUERY_STRING'].
		 * To ensure proper protection, developers must access GET parameters only through $_GET.
		 */
		public static function getIpRestrictedGetParametersArray() {
			return [

				 'debug',

			];
		}

		/**
		 * Array of IPs that are allowed to access the IP restricted URLs
		 */
		public static function getIpsWithPermissionToRestrictedUrlsArray() {
			return [

				'127.0.0.1',

				'162.251.146.191', // us-bmdev
				'31.154.135.98',   // IL office
				'80.240.21.168',   // AL Office
				'185.30.144.46',   // AL Office
				'195.28.181.203',  // Eli
				'91.223.106.38',   // Eli & DrTraffic
				'188.166.105.40',  // DrTraffic
				'62.90.110.166',   // MB
				'185.126.237.60',  // RO
				'95.179.129.168',  // TO
				'78.141.239.156',  // JD
				'31.154.174.174',  // South office
				'91.132.4.72',     // RO office
				"147.78.2.251",    // IL spare
				"164.92.255.105",  // Octo monitoring

			];
		}
		
		/**
		 * Array of URLs allowed only with authentication
		 *
		 * NOTES:
		 * - each URL must start with '/'
		 * - all sub-paths under an authentication-restricted URL are also authentication-restricted
		 */
		public static function getAuthenticationRestrictedUrlsArray() {
			return [

				// '/put/your/url/here/',

			];
		}

		/**
		 * Array of GET parameters allowed only with authentication
		 *
		 * If the client is not authenticated, these parameters are removed from $_GET, an error is logged,
		 * and the request is processed as if these parameters were never present.
		 *
		 * NOTES:
		 * The controller intentionally does not modify $_REQUEST or $_SERVER['QUERY_STRING'].
		 * To ensure proper protection, developers must access GET parameters only through $_GET.
		 */
		public static function getAuthenticationRestrictedGetParametersArray() {
			return [

				'force_shift',
				'purx',

			];
		}

		/**
		 * Map of URLs that contains a dynamic virtual folder
		 *
		 * This is a map of 'key' => 'value' where:
		 * - 'key'    is the URL which stands at the top of the hierarchy after which is the dynamic folder
		 * - 'value'  is the name of the physical directory under which the resources are stored
		 *
		 * NOTES:
		 * - URL must begin with '/'
		 *
		 * Example:
		 * 	The following setting defines a dynamic virtual folder under /lp/deals
		 *	where the resources are under /lp/deals/_files_
		 *
		 *	'/lp/deals' => '_files_'
		 *
		 *	This means that the following request: /lp/deals/1023/img/logo.png will return this file:
		 *	/lp/deals/_files_/img/logo.png 
		 *
		 *  IMPORTANT: it is best practice to include the physical part in the restricted URLs ( '/lp/deals/_files_' in this case )
		 */
		public static function getDynamicVirtualFoldersArray() {
			return [
				
				// '/lp/deals' => '_files_',	// IMPORTANT: it is best practice to include the physical part in the restricted URLs ( '/lp/deals/_files_' in this case )

			];
		}

		/**
		 * Map of URLs that are aliases of PHP files
		 *
		 * This is a map of 'key' => 'value' where:
		 * - 'key'    is the URL which acts as alias to a PHP file
		 * - 'value'  is the URL of the PHP file that needs to be required (can be under restricted folder) 
		 *
		 * NOTES:
		 * - URL must begin with '/'
		 */
		public static function getPHPAliasUrlsArray() {
			return [
			
				// '/put/your/url/here/' => '/put/PHP/file/url/here',

				'/api/auth/init/'		=> '/_controller_v3_/ctrl/auth/init_auth_session.php',
				'/api/auth/activate/'	=> '/_controller_v3_/ctrl/auth/activate_auth_session.php',
				'/api/event/onload/'	=> '/_controller_v3_/ctrl/monitoring/handle_onload_event.php',
				'/clear-cache/'			=> '/_controller_v3_/ctrl/cache/clear_cache.php',

			];
		}
		
		/**
		 * Map of URLs managed by a CMS
		 *
		 * This is a map of 'key' => 'value' where:
		 * - 'key'    is the URL which stands at the top of the hierarchy managed by a CMS
		 * - 'value'  is the URL of the entry point to the CMS which will handle all requests to non-existing resources
		 *
		 * NOTES:
		 * - URL must begin with '/'
		 */
		public static function getCmsUrlsArray() {
			return [
				
				// '/put/your/url/here/' => '/put/CMS/entry/point/url/here',
				
				// '/' => '/index.php',            // WordPress is installed under root dir
				// '/blog/' => '/blog/index.php',  // WordPress is installed under '/blog' dir
				// '/foo' => '/bots-trap.php',    // Handle all requests for /foo/* in one place ...

			];
		}
	}
?>
