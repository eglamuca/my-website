<?php
/**
 * 2025-03-27 Added support for authentication-restricted parameters and IP-restricted parameters
 * 2025-03-26 Added support for authentication-restricted URLs
 * 2025-03-23 Added support for restricting resource names to allowed IPs only
 * 2024-01-19 AWS Cloudfront IP detection added
 * 2020-07-20 Version 3.0 created
 * 2016-09-26 Add support for .woff2 file extension
 * 2014-12-22 Add support to CONTROLLER_LOG_REQUESTS == false setting
 * 2013-10-24 Version 2.0 created
 * 2013-09-24 Version 1.0 created
 *
 * The controller is the entry point for handling requests.
 */
 
	/**
	 * If the request contains a dynamic folder, return its name, otherwise an empty string is returned
	 */
	function controller_get_dynamic_folder_name() {
		return Controller::getInstance()->getDynamicFolderName();
	}

	// Init the controller
	Controller::getInstance();

	// Require controller settings
	$controller_settings_php_file_fullname = CONTROLLER_SETTINGS_DIR_FULLNAME . "/controller-settings.php";
	$file_name = $controller_settings_php_file_fullname; if (!is_file($file_name)) { trigger_error("File not found '$file_name'", E_USER_ERROR); exit(0); }

	require $controller_settings_php_file_fullname;
	
	// Make sure mandatory settings exist: getForbiddenUrlsArray, getIpRestrictedUrlsArray, getIpRestrictedResourceNamesArray
	if (! method_exists("ControllerSettings", "getForbiddenUrlsArray")) 	{ trigger_error("Mandatory method not found: ControllerSettings::getForbiddenUrlsArray()", E_USER_ERROR); exit(0); }
	if (! method_exists("ControllerSettings", "getIpRestrictedUrlsArray"))	{ trigger_error("Mandatory method not found: ControllerSettings::getIpRestrictedUrlsArray()", E_USER_ERROR); exit(0); }

	// Write request to log, if this fails, no point to continue
	if ((defined("CONTROLLER_LOG_REQUESTS") && (CONTROLLER_LOG_REQUESTS == false))) {
		// For backward compatibility, we always write to log, unless "CONTROLLER_LOG_REQUESTS" is defined and set to false
	}
	else if (logger_logRequest($_SERVER, NULL, CONTROLLER_REQUESTS_LOG_FILE_FULLNAME) === false) {
		trigger_error("Logger failed", E_USER_ERROR); exit(0);
	}

	// Parse the request
	Controller::getInstance()->parseRequest();

	$errors = Controller::getInstance()->getErrors();
	$notes =  Controller::getInstance()->getNotes();
	$headers = Controller::getInstance()->getHeaders();
	$resource_fullname = Controller::getInstance()->getResourceFullname();
	if (function_exists("header_remove")) { header_remove("X-Powered-By"); }

	// If there are errors, but headers are empty, we send response "200 OK"
	// in such case there must be a note about it, so we know it is intentional and not a bug
	if (!empty($errors) && empty($notes) && empty($headers)) {
		trigger_error("Errors found while both notes and headers are empty (uid=" . main_getInstanceUid() . ")", E_USER_NOTICE);
		$errors[] = "errors found while both notes and headers are empty";
	}

	if (Controller::getInstance()->getResponseType() == Controller::RESPONSE_HEADERS_ONLY) {
		// Make sure resource full name is empty
		if (strlen($resource_fullname) > 0) {
			trigger_error("RESPONSE_HEADERS_ONLY but resource full name not empty (uid=" . main_getInstanceUid() . "; value=" . $resource_fullname . ")", E_USER_NOTICE);
		}
		// Set headers
		foreach ($headers as $header) {
			header($header);
		}

		writeResponseErrorsLog($errors, $notes, $headers);
		exit(0);
	}
	else if (Controller::getInstance()->getResponseType() == Controller::RESPONSE_HEADERS_WITH_BODY) {

		// Make sure resource full name is not empty
		if (strlen($resource_fullname) < 1) {
			trigger_error("RESPONSE_HEADERS_WITH_BODY but resource full name empty (uid=" . main_getInstanceUid() . ")", E_USER_NOTICE);
			$errors[] = "RESPONSE_HEADERS_WITH_BODY but resource full name empty";
			$headers[] = "HTTP/1.0 404 Not Found";
			$resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . "/404.php";
		}

		// If resource is for non-existing file set it to "404.php"
		if (! is_file($resource_fullname)) {
			$errors[] = "Not found (value=" . $resource_fullname . ")";
			$headers[] = "HTTP/1.0 404 Not Found";
			$resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . "/404.php";
			// If "404.php" not exist just return headers
			if (! is_file($resource_fullname)) {
				$errors[] = "Not found (value=" . $resource_fullname . ")";
				// Set headers
				foreach ($headers as $header) {
					header($header);
				}

				writeResponseErrorsLog($errors, $notes, $headers);
				exit(0);
			}
		}

		// Get the extension
		$resource_fullname_path_parts = pathinfo($resource_fullname);
		$resource_fullname_extension_lower = "";
		if (isset($resource_fullname_path_parts["extension"])) {
			$resource_fullname_extension_lower = strtolower($resource_fullname_path_parts["extension"]);
		}
		$resource_fullname_filesize = filesize($resource_fullname);

		// If not "php", deliver the file
		if (strcmp($resource_fullname_extension_lower, "php") != 0) {
			// Deliver supported file types with the suitable Content-Type header
			// 7z, .bmp, .css, .eot, .flv, .gif, .html, .ico, .jpg, .js, .mp4, .otf, .pdf, .png, .svg, .swf, .ttf, .txt, .woff, .woff2, .xml, .zip
			switch ($resource_fullname_extension_lower) {
				case "7z"    :	header("Content-Type: application/x-7z-compressed");
								header("Content-Disposition: attachment; filename=\"" . basename($resource_fullname) . "\"");
								header("Content-Length: " . $resource_fullname_filesize);
								header("Pragma: no-cache");
								header("Expires: 0");
								if (ob_get_level()) { ob_end_clean(); }
								ini_set("output_buffering", 0);
								ini_set("zlib.output_compression", 0);
								break;
				case "bmp"   :	header("Content-Type: image/bmp");						break;
				case "css"   :	header("Content-Type: text/css");						break;
				case "eot"   :	header("Content-Type: application/vnd.ms-fontobject");	break;
				case "flv"   :	header("Content-Type: video/x-flv");					break;
				case "gif"   :	header("Content-Type: image/gif");						break;
				case "html"  :	header("Content-Type: text/html");						break;
				case "ico"   :	header("Content-Type: image/x-icon");					break;
				case "jpeg"  :	header("Content-Type: image/jpeg");						break;
				case "jpg"   :	header("Content-Type: image/jpeg");						break;
				case "js"    :	header("Content-Type: application/javascript");			break;
				case "json"  :	header("Content-Type: application/json");				break;
				case "map"   :	header("Content-Type: application/json");				break;
				case "mp4"   :	header("Content-Type: video/mpeg");						break;
				case "otf"   :	header("Content-Type: application/x-font-otf");			break;
				case "pdf"   :	header("Content-Type: application/pdf");				break;
				case "png"   :	header("Content-Type: image/png");						break;
				case "svg"   :	header("Content-Type: image/svg+xml");					break;
				case "swf"   :	header("Content-Type: application/x-shockwave-flash");	break;
				case "ttf"   :	header("Content-Type: application/x-font-ttf");			break;
				case "txt"   :	header("Content-Type: text/plain");						break;
				case "webp"  :	header("Content-Type: image/webp");						break;
				case "woff"  :	header("Content-Type: application/x-font-woff");		break;
				case "woff2" :	header("Content-Type: application/x-font-woff");		break;
				case "xml"   :	header("Content-Type: text/xml");						break;
				case "zip"   :	header("Content-Type: application/zip");
								header("Content-Disposition: attachment; filename=\"" . basename($resource_fullname) . "\"");
								header("Content-Length: " . $resource_fullname_filesize);
								header("Pragma: no-cache");
								header("Expires: 0");
								if (ob_get_level()) { ob_end_clean(); }
								ini_set("output_buffering", 0);
								ini_set("zlib.output_compression", 0);
								break;
				default      : {
					$errors[] = "Unsupported file type (ext=" . $resource_fullname_extension_lower . ")";
					$headers[] = "HTTP/1.0 404 Not Found";

					// Set headers
					foreach ($headers as $header) {
						header($header);
					}

					writeResponseErrorsLog($errors, $notes, $headers);
					exit(0);
				}
			}

			// Set headers
			foreach ($headers as $header) {
				header($header);
			}

			if (ob_get_level()) { ob_flush(); } // flush output
			flush();
			readfile($resource_fullname);

			writeResponseErrorsLog($errors, $notes, $headers);
			exit(0);
		}
	}
	else {
		trigger_error("Unexpected response type (uid=" . main_getInstanceUid() . "; value=" . Controller::getInstance()->getResponseType() . ")", E_USER_NOTICE);
		$errors[] = "Unexpected response type (value=" . Controller::getInstance()->getResponseType() . ")";
		header("HTTP/1.0 404 Not Found");

		writeResponseErrorsLog($errors, $notes, array("HTTP/1.0 404 Not Found"));
		exit(0);
	}

	// If we got here, it means we need to require a PHP file

	// Make sure file exists
	if (! is_file($resource_fullname)) {
		$errors[] = "Not found (value=" . $resource_fullname . ")";
		$headers[] = "HTTP/1.0 404 Not Found";
		$resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . "/404.php";
		// If "404.php" not exist just return headers
		if (! is_file($resource_fullname)) {
			$errors[] = "Not found (value=" . $resource_fullname . ")";
			// Set headers
			foreach ($headers as $header) {
				header($header);
			}

			writeResponseErrorsLog($errors, $notes, $headers);
			exit(0);
		}
	}

	// Set headers
	foreach ($headers as $header) {
		header($header);
	}

	writeResponseErrorsLog($errors, $notes, $headers);

	$_SERVER["SCRIPT_FILENAME"] = $resource_fullname; // The absolute pathname of the currently executing script
	$_SERVER["PATH_TRANSLATED"] = ""; // Not sure why, but actual tests show it is always empty ... $resource_fullname; // Filesystem- (not document root-) based path to the current script, after the server has done any virtual-to-real mapping.

	$_SERVER["ORIG_PATH_INFO"] = ""; // We set this to empty since we don't support path names trailing the PHP script // $_SERVER["SCRIPT_NAME"]; // Original version of 'PATH_INFO' before processed by PHP. $_SERVER["ORIG_PATH_INFO"] Contains any client-provided pathname information trailing the actual script filename but preceding the query string, if available. For instance, if the current script was accessed via the URL http://www.example.com/php/path_info.php/some/stuff?foo=bar, then $_SERVER['PATH_INFO'] would contain /some/stuff.

	$script_path_relative_to_document_root = substr($resource_fullname, strlen(WEBSITE_ROOT_DIR_FULLNAME));

	$_SERVER["SCRIPT_NAME"] = $script_path_relative_to_document_root; // Contains the current script's path (relative to document root)
	$_SERVER["DOCUMENT_URI"] = $script_path_relative_to_document_root; // Contains the current script's path (relative to document root)
	$_SERVER["PHP_SELF"] = $script_path_relative_to_document_root;	// The filename of the currently executing script, relative to the document root. For instance, $_SERVER['PHP_SELF'] in a script at the address http://example.com/test.php/foo.bar would be /test.php/foo.bar.

	chdir(dirname($resource_fullname));chdir("."); // We must call chdir(".") in order to overcome PHP bug
	@ini_set("error_log", GENERAL_PHP_ERRORS_LOG_FULLNAME); // We are leaving the controller, send all PHP errors to another log
	require $resource_fullname;
	exit(0);

	/**
	 * If there are errors, write an entry in the response errors log
	 */
	function writeResponseErrorsLog($errors, $notes, $headers) {

		if (empty($errors)) { return; } // If there are no errors, do nothing

		$additional_info_str = "ERRORS=[" . implode(",", $errors) . "]\tNOTES=[";
		if (!empty($notes)) { $additional_info_str = $additional_info_str . implode(",", $notes); }
		$additional_info_str = $additional_info_str . "]\tHEADERS=[";
		if (!empty($headers)) { $additional_info_str = $additional_info_str . implode(",", $headers); }
		$additional_info_str = $additional_info_str . "]";

		if (logger_logRequest($_SERVER, $additional_info_str, CONTROLLER_RESPONSE_ERRORS_LOG_FILE_FULLNAME) === false) { trigger_error("Failed logging response errors (uid=" . main_getInstanceUid() . ")", E_USER_NOTICE); }
	}

	/**
	 * Controller: Core class for request handling and routing.
	 *
	 * Manages the lifecycle of an HTTP request:
	 * - Parsing and validation
	 * - Access control
	 * - Dynamic routing (virtual folders, CMS, PHP aliases)
	 * - Response header and resource handling
	 *
	 * Implements a singleton pattern.
	 */
	class Controller {

		const RESPONSE_HEADERS_ONLY = 1001;
		const RESPONSE_HEADERS_WITH_BODY = 1002;

		// Singleton code
		private static $__instance = null;
		private function __construct() {}
		private function __clone() {}

		static public function getInstance() {
			if (self::$__instance == null) { self::$__instance = new Controller(); }
			return self::$__instance;
		}


		private $response_type = Controller::RESPONSE_HEADERS_ONLY;
		private $resource_fullname = "";
		private $dynamic_folder_name = "";
		private $headers = array();
		private $errors = array();
		private $notes = array();

		private $parsed_request_url = array();

		public function getResponseType() {
			return $this->response_type;
		}

		public function getResourceFullname() {
			return $this->resource_fullname;
		}

		public function getDynamicFolderName() {
			return $this->dynamic_folder_name;
		}

		public function getHeaders() {
			return $this->headers;
		}

		public function getErrors() {
			return $this->errors;
		}

		public function getNotes() {
			return $this->notes;
		}

		/**
		 * Set the response configuration.
		 *
		 * This sets the response type (headers only or headers + body), the headers to be sent,
		 * and the full path to the resource that should be served (if applicable).
		 *
		 * Invalid or unexpected values are sanitized, and warnings are logged for unexpected input.
		 */
		public function setResponse($response_type, $headers, $resource_fullname) {
			$safe_response_type = Controller::RESPONSE_HEADERS_ONLY;
			$safe_headers = array();
			$safe_resource_fullname = "";

			if (!isset($response_type)) {
				trigger_error("response_type not set", E_USER_NOTICE);
			}
			else if (($response_type != Controller::RESPONSE_HEADERS_ONLY) && ($response_type != Controller::RESPONSE_HEADERS_WITH_BODY)) {
				trigger_error("unexpected value (response_type=$response_type)", E_USER_NOTICE);
			}
			else {
				$safe_response_type = $response_type;
			}

			if (isset($headers) && is_array($headers)) {
				$safe_headers = $headers;
			}

			if (isset($resource_fullname) && (strlen($resource_fullname) > 0)) {
				$safe_resource_fullname = $resource_fullname;
			}

			$this->response_type = $safe_response_type;
			$this->headers = $safe_headers;
			$this->resource_fullname = $safe_resource_fullname;
		}

		/**
		 * Parse and validate the incoming request.
		 *
		 * This method performs the full request handling logic:
		 * - Validates request format and method
		 * - Enforces access restrictions (forbidden, IP-restricted, authentication-restricted)
		 * - Removes restricted GET parameters if needed
		 * - Resolves the requested resource (static, PHP alias, or CMS handler)
		 * - Sets response type accordingly (headers only or headers + body)
		 */
		public function parseRequest() {

			$this->response_type = Controller::RESPONSE_HEADERS_ONLY;
			$this->resource_fullname = "";
			$this->headers = array();
			$this->errors = array();

			// Perform basic validation of the request
			// if it is not valid, we return "200 Ok"
			$this->basicRequestValidation();
			if (!empty($this->errors)) {
				$this->response_type = Controller::RESPONSE_HEADERS_ONLY;
				$this->headers[] = "HTTP/1.0 200 OK";
				return;
			}

			// If request is forbidden we return 404 Not Found
			$this->validateForbiddenRequest();
			if (!empty($this->errors)) {
				$this->response_type = Controller::RESPONSE_HEADERS_ONLY;
				$this->headers[] = "HTTP/1.0 404 Not Found";
				return;
			}

			// If request is IP restricted and request IP has no permission we return 404 Not Found
			$this->validateIpRestrictedRequest();
			if (!empty($this->errors)) {
				$this->response_type = Controller::RESPONSE_HEADERS_ONLY;
				$this->headers[] = "HTTP/1.0 404 Not Found";
				return;
			}

			// If the request is authentication-restricted and the user is not authenticated, return 404 Not Found
			$this->validateAuthenticationRestrictedRequest();
			if (!empty($this->errors)) {
				$this->response_type = Controller::RESPONSE_HEADERS_ONLY;
				$this->headers[] = "HTTP/1.0 404 Not Found";
				return;
			}
			
			// Before determining the resource to serve, unset all restricted parameters from the array of GET parameters (_GET)
			// this function may set errors (logged later), but execution continues with these parameters removed
			$this->unsetRestrictedGetParameters();
			
			$this->setResourceFullName();

			// Check if the requested resource is a directory
			if (is_dir($this->resource_fullname)) {
				// When requesting a directory, the default resource file is "index.php"
				// however if it doesn't exist, we support also "index.html"
				$default_index_php_fullname = $this->resource_fullname . "/index.php";
				$default_index_html_fullname = $this->resource_fullname . "/index.html";
				
				$this->resource_fullname = $default_index_php_fullname;
				
				if ((! file_exists($default_index_php_fullname)) && (file_exists($default_index_html_fullname))) {
					$this->resource_fullname = $default_index_html_fullname;
				}
			}

			// If request is for non existing resource,
			// check if it is an alias for a PHP
			// or is there a CMS that handles this request
			if (! file_exists($this->resource_fullname)) {
				if ($this->isRequestPHPAlias()) {
					return;
				}
				else if ($this->isRequestCMS()) {
					return;
				}
			}

			$this->response_type = Controller::RESPONSE_HEADERS_WITH_BODY;
		}

		/**
		 * Make sure request has mandatory elements and their values are supported
		 */
		private function basicRequestValidation() {

			$key_name = "REQUEST_METHOD";  if (!isset($_SERVER["$key_name"])) { $this->errors[] = "$key_name not set"; } else if (strlen($_SERVER["$key_name"]) == 0) { $this->errors[] = "$key_name empty"; }
			$key_name = "SERVER_PROTOCOL"; if (!isset($_SERVER["$key_name"])) { $this->errors[] = "$key_name not set"; } else if (strlen($_SERVER["$key_name"]) == 0) { $this->errors[] = "$key_name empty"; }
			$key_name = "HTTP_HOST";       if (!isset($_SERVER["$key_name"])) { $this->errors[] = "$key_name not set"; } else if (strlen($_SERVER["$key_name"]) == 0) { $this->errors[] = "$key_name empty"; }
			$key_name = "REQUEST_URI";     if (!isset($_SERVER["$key_name"])) { $this->errors[] = "$key_name not set"; } else if (strlen($_SERVER["$key_name"]) == 0) { $this->errors[] = "$key_name empty"; }
			
			$allow_user_agent_not_set = false; if (defined("CONTROLLER_ALLOW_HTTP_USER_AGENT_NOT_SET")) { $allow_user_agent_not_set = CONTROLLER_ALLOW_HTTP_USER_AGENT_NOT_SET; }
			if (! $allow_user_agent_not_set) {
				$key_name = "HTTP_USER_AGENT"; if (!isset($_SERVER["$key_name"])) { $this->errors[] = "$key_name not set"; } else if (strlen($_SERVER["$key_name"]) == 0) { $this->errors[] = "$key_name empty"; }
			}

			if (empty($this->errors)) {
				// "REQUEST_METHOD": we support only "GET" or "POST"
				if ((strcmp($_SERVER["REQUEST_METHOD"], "GET") != 0) && (strcmp($_SERVER["REQUEST_METHOD"], "POST") != 0))  { $this->errors[] = "REQUEST_METHOD not supported"; }
				// "SERVER_PROTOCOL": we support only "HTTP/1.0" or "HTTP/1.1"
				if ((strcmp($_SERVER["SERVER_PROTOCOL"], "HTTP/1.0") != 0) && (strcmp($_SERVER["SERVER_PROTOCOL"], "HTTP/1.1") != 0)) { $this->errors[] = "SERVER_PROTOCOL not supported (value=" . $_SERVER["SERVER_PROTOCOL"] . ")"; }
				// "REQUEST_URI": must begin with "/"
				if (strncmp($_SERVER["REQUEST_URI"], "/", 1) != 0) { $this->errors[] = "REQUEST_URI not begins with '/'"; }
			}

			if (empty($this->errors)) {
				$request_uri = $_SERVER["REQUEST_URI"];
				if ("/" == $request_uri[0]) {
					$request_uri = "/" . ltrim($request_uri, "/");
				}
				if ((($this->parsed_request_url = parse_url($request_uri)) === false) || (!isset($this->parsed_request_url["path"]))) {
					trigger_error("Parse URL failed (uid=" . main_getInstanceUid() . "; REQUEST_URI=" . $_SERVER["REQUEST_URI"] . ")", E_USER_NOTICE);
					$this->errors[] = "REQUEST_URI not parsed";
					$this->parsed_request_url = array();
				}
			}
		}

		/**
		 * Check if request is forbidden:
		 * a forbidden request is a request that begins with one of the forbidden URLs in the forbidden URLs array
		 */
		private function validateForbiddenRequest() {
			$forbidden_urls = array(); if (method_exists("ControllerSettings", "getForbiddenUrlsArray")) { $forbidden_urls = ControllerSettings::getForbiddenUrlsArray(); }
			$forbidden_prefix = Controller::findUrlPrefix($this->parsed_request_url["path"], $forbidden_urls);
			if (strlen($forbidden_prefix) > 0) {
				$this->errors[] = "Forbidden (prefix=" . $forbidden_prefix . ")";
			}
		}

		/**
		 * Check if request is IP restricted:
		 * a request is IP restricted if it comes from an IP not in the allowed IPs list and
		 * it starts with one of the IP restricted URLs, or it requests one of the IP restricted resources
		 */
		private function validateIpRestrictedRequest() {
			$client_ip = main_getClientIP();
			$ips_with_permission_to_restricted_urls = array(); if (method_exists("ControllerSettings", "getIpsWithPermissionToRestrictedUrlsArray")) { $ips_with_permission_to_restricted_urls = ControllerSettings::getIpsWithPermissionToRestrictedUrlsArray(); }
			if (! in_array($client_ip, $ips_with_permission_to_restricted_urls, true)) {
				// Request is from an IP without permission to access restricted URLs/resources
				
				$restricted_urls = array(); if (method_exists("ControllerSettings", "getIpRestrictedUrlsArray")) { $restricted_urls = ControllerSettings::getIpRestrictedUrlsArray(); }
				$ip_restricted_prefix = Controller::findUrlPrefix($this->parsed_request_url["path"], $restricted_urls);
				if (strlen($ip_restricted_prefix) > 0) {
					// Request URL starts with a restricted prefix
					$this->errors[] = "Restricted URL (prefix=" . $ip_restricted_prefix . ")";
				}
				
				$requested_resource_name = basename($this->parsed_request_url["path"]);
				if (strlen($requested_resource_name) > 0) {
					$restricted_resource_names = array(); if (method_exists("ControllerSettings", "getIpRestrictedResourceNamesArray")) { $restricted_resource_names = ControllerSettings::getIpRestrictedResourceNamesArray(); }
					if (in_array($requested_resource_name, $restricted_resource_names, true)) {
						// Request is for a restricted resource name
						$this->errors[] = "Restricted resource (" . $requested_resource_name . ")";
					}
				}
			}
		}

		/**
		 * Check if request is authentication-restricted:
		 * a request is authentication-restricted if it starts with one of the authentication-restricted URLs and the user is not authenticated.
		 * 
		 * NOTE: first we check if the URL matches a restricted prefix to avoid unnecessary authentication checks.
		 */
		private function validateAuthenticationRestrictedRequest() {
			// First check if the URL matches a restricted prefix to avoid unnecessary authentication checks.
			$authentication_restricted_urls = array(); if (method_exists("ControllerSettings", "getAuthenticationRestrictedUrlsArray")) { $authentication_restricted_urls = ControllerSettings::getAuthenticationRestrictedUrlsArray(); }
			$authentication_restricted_prefix = Controller::findUrlPrefix($this->parsed_request_url["path"], $authentication_restricted_urls);
			if (strlen($authentication_restricted_prefix) > 0) {
				// Request URL starts with an authentication-restricted prefix, check authentication
				if (main_isAuth() == false) {
					$this->errors[] = "Authentication restricted URL (prefix=" . $authentication_restricted_prefix . ")";
				}
			}
		}

		/**
		 * Unset restricted parameters from $_GET only
		 *
		 * NOTE: This function intentionally unsets only $_GET values.
		 *       It does NOT modify $_REQUEST — developers must ensure they use $_GET (not $_REQUEST)
		 *       when working with user input in the context of these restrictions.
		 *
		 * This design allows flexibility and keeps $_REQUEST available for special use cases.
		 */
		private function unsetRestrictedGetParameters() {
			$any_param_unset = false;
			$client_ip = main_getClientIP();

			// Combine all restricted parameters we want to check (ip-restricted and authentication-restricted)
			$ip_restricted_params = array(); if (method_exists("ControllerSettings", "getIpRestrictedGetParametersArray")) { $ip_restricted_params = ControllerSettings::getIpRestrictedGetParametersArray(); }
			$auth_restricted_params = array(); if (method_exists("ControllerSettings", "getAuthenticationRestrictedGetParametersArray")) { $auth_restricted_params = ControllerSettings::getAuthenticationRestrictedGetParametersArray(); }

			// Remove ip-restricted parameters if client IP is not whitelisted
			if (!in_array($client_ip, ControllerSettings::getIpsWithPermissionToRestrictedUrlsArray(), true)) {
				foreach ($ip_restricted_params as $param) {
					if (isset($_GET[$param])) {
						unset($_GET[$param]);
						$any_param_unset = true;
						$this->errors[] = "Removed IP-restricted parameter (" . $param . ")";
					}
				}
			}

			// Remove authentication-restricted parameters if client is not authenticated
			// NOTE: to avoid unnecessary calls to main_isAuth(), we first check if any of the restricted params are set in the $_GET to begin with
			foreach ($auth_restricted_params as $param) {
				if (isset($_GET[$param])) {
					if (main_isAuth() == false) {
						unset($_GET[$param]);
						$any_param_unset = true;
						$this->errors[] = "Removed authentication-restricted parameter (" . $param . ")";
					}
				}
			}
			
			if ($any_param_unset) {
				// This note ensures the controller does not falsely assume something went wrong
				$this->notes[] = "Restricted GET parameters removed as expected; continuing with request.";
			}
		}

		/**
		 * Set the fullname of the requested resource
		 * if it is under a dynamic virtual folder, set the correct values
		 */
		private function setResourceFullName() {
			
			$this->resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . rtrim($this->parsed_request_url["path"], "/");
			
			// Check if the request contains a dynamic virtual folder
			$dvf_array = array(); if (method_exists("ControllerSettings", "getDynamicVirtualFoldersArray")) { $dvf_array = ControllerSettings::getDynamicVirtualFoldersArray(); }
			$dvf_key = Controller::findUrlPrefix($this->parsed_request_url["path"], array_keys($dvf_array));
			if (0 < strlen($dvf_key)) {
				
				$physical_directory_name = $dvf_array[$dvf_key];
				$url_path_before_dvf = $dvf_key;
				$dvf_folder_name = "";
				$path_after_dvf = "";
				
				// Make sure it ends with /
				if (1 < strlen($url_path_before_dvf)) {
					$url_path_before_dvf = rtrim($url_path_before_dvf, "/") . "/";
				}
				
				$temp_path = substr($this->parsed_request_url["path"], strlen($url_path_before_dvf)); // remove the part before the dvf_array
				// Make sure there is a dynamic virtual folder
				if (0 < strlen($temp_path)) {
					$temp_explode = explode("/", $temp_path, 2);
					if (isset($temp_explode[0])) {
						$dvf_folder_name = $temp_explode[0];
					}
					if (isset($temp_explode[1])) {
						$path_after_dvf = $temp_explode[1];
						$path_after_dvf = "/" . $path_after_dvf;
					}
					
					$this->resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . $url_path_before_dvf . $physical_directory_name . $path_after_dvf;
					$this->dynamic_folder_name = $dvf_folder_name;
				}
			}
		}

		/**
		 * Check if request is an alias for a PHP that needs to be required
		 */
		private function isRequestPHPAlias() {
			$php_alias_array = array(); if (method_exists("ControllerSettings", "getPHPAliasUrlsArray")) { $php_alias_array = ControllerSettings::getPHPAliasUrlsArray(); }
			$alias_key = Controller::findUrlPrefix($this->parsed_request_url["path"], array_keys($php_alias_array));
			if (strlen($alias_key) > 0) {
				$the_php_file = $php_alias_array["$alias_key"];
				$this->response_type = Controller::RESPONSE_HEADERS_WITH_BODY;
				$this->resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . $the_php_file;
				return true;
			}

			return false;
		}

		/**
		 * Check if request is to be handled by CMS
		 */
		private function isRequestCMS() {
			$cms_array = array(); if (method_exists("ControllerSettings", "getCmsUrlsArray")) { $cms_array = ControllerSettings::getCmsUrlsArray(); }
			$cms_key = Controller::findUrlPrefix($this->parsed_request_url["path"], array_keys($cms_array));
			if (strlen($cms_key) > 0) {
				$cms_handler = $cms_array["$cms_key"];
				$this->response_type = Controller::RESPONSE_HEADERS_WITH_BODY;
				$this->resource_fullname = WEBSITE_ROOT_DIR_FULLNAME . $cms_handler;
				return true;
			}

			return false;
		}

		/**
		 * Return the prefix in the URL prefix array which the given URL begins with or empty string
		 */
		private static function findUrlPrefix($url, $url_prefix_array) {
			$found_prefix = "";

			// We make sure given URL ends with "/" so comparison is easier
			if ($url[strlen($url) - 1] != "/") { $url = $url . "/"; }

			$prefix_len = 0;
			$prefix_with_trailing_slash = "/";
			// Check if given URL begins with one of the URL prefix
			foreach ($url_prefix_array as $prefix) {
				$prefix_len = strlen($prefix);
				if (strlen($prefix) > 0) {
					// We make sure prefix URL ends with "/" so comparison is easier
					$prefix_with_trailing_slash = $prefix;
					if (substr($prefix_with_trailing_slash,$prefix_len - 1,1) != "/") { $prefix_with_trailing_slash = $prefix_with_trailing_slash . "/"; }
					// We test if given URL begins with URL prefix (now that both ends with "/")
					if (strncmp($url, $prefix_with_trailing_slash, strlen($prefix_with_trailing_slash)) == 0) {
						$found_prefix = $prefix;
						break;
					}
				}
			}
			return $found_prefix;
		}

	}
?>
