<?php
/**
 * 2023-04-27 major merge of latest changes
 *
 * all functions that the controller exposes
 */
	
	/**
	 * these globla variables must exist
	 */
	if (! isset($g_controller_main_execution_start_timestamp_microsec_float)) { trigger_error("global variable not set \"g_controller_main_execution_start_timestamp_microsec_float\"", E_USER_ERROR); exit(0); }
	if (! isset($g_controller_main_execution_start_timestamp_utc_string)) { trigger_error("global variable not set \"g_controller_main_execution_start_timestamp_utc_string\"", E_USER_ERROR); exit(0); }
	if (! isset($g_controller_main_instance_uid)) { trigger_error("global variable not set \"g_controller_main_instance_uid\"", E_USER_ERROR); exit(0); }

	/**
	 * return the execution start timestamp microseconds as float
	 * see: http://www.php.net/manual/en/function.date.php
	 */
	function main_getExecutionStartTimestampMicrosecFloat() {
		global $g_controller_main_execution_start_timestamp_microsec_float;
		return $g_controller_main_execution_start_timestamp_microsec_float;
	}
	
	/**
	 * return the execution start timestamp (UTC) as string ("d/m/Y H:i:s e")
	 * see: http://www.php.net/manual/en/function.date.php
	 */
	function main_getExecutionStartTimestampUTC() {
		global $g_controller_main_execution_start_timestamp_utc_string;
		return $g_controller_main_execution_start_timestamp_utc_string;
	}

	/**
	 * return the unique id of this instance
	 */
	function main_getInstanceUid() {
		global $g_controller_main_instance_uid;
		return $g_controller_main_instance_uid;
	}
	
	/**
	 * return the number of seconds (with a 3 decimal point precision) that has passed since the execution start
	 */
	function main_getExecutionDurationSec() {
		return number_format(microtime(true) - main_getExecutionStartTimestampMicrosecFloat(), 3);
	}
	
	/**
	 * return the IP address of the client of this request
	 */
	function main_getClientIP() {
		$client_ip = $_SERVER["REMOTE_ADDR"];
		if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
			$client_ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
		}
		else if (isset($_SERVER["HTTP_CLOUDFRONT_VIEWER_ADDRESS"])) {
			$client_ip = strtok($_SERVER["HTTP_CLOUDFRONT_VIEWER_ADDRESS"], ":");
		}
		return $client_ip;
	}
	
	/**
	 * returns true if the current request is authenticated (auth cookie is present and verified) otherwise returns false
	 */
	function main_isAuth() {
		if (function_exists('authentication_isAuthenticated')) {
			return authentication_isAuthenticated();
		}
		return false;
	}

	/**
	 * report onload event
	 *
	 * this adds a code that reports the "onload" event back to the controller monitoring compnent
	 * it should be added to landing pages at the bottom
	 */
	function main_reportOnloadEvent() {
		echo "<script>";
		echo "window.addEventListener(\"load\", function () {";
		echo "let token = \"" . main_getInstanceUid() . "\";";
		echo "let timestamp = \"" . main_getExecutionStartTimestampMicrosecFloat() . "\";";
		echo "fetch('/api/event/onload/?controller_id=' + token + '&timestamp=' + timestamp, { method: 'GET', headers: { 'Content-Type': 'application/json' }}).then((response) => response.json()) });";
		echo "</script>";
	}

?>