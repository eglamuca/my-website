<?php
/**
 * 2025-03-26 created
 *
 * Authentication mechanism for the controller.
 *
 * This file implements a secure, two-phase authentication flow to verify clients via a central authentication server.
 *
 * 1. Session Initialization: authentication_initSession()
 *
 *    The central authentication server calls authentication_initSession() on this controller  
 *    to create a short-lived, pending session. The session is associated with a specific user/device  
 *    using client identifiers (IP, User-Agent, Referrer, etc.) and an auth token.
 *
 * 2. Session Activation: authentication_activateSession()
 *
 *    The client browser performs a cross-site CORS request to authentication_activateSession(), passing the session ID (SID).
 *    The controller verifies the IP and User-Agent match the pending session and if valid and within a short time window,
 *    promotes it to an active session and sets a secure cookie (asid).
 *
 * 3. Session Validation: authentication_isAuthenticated()
 *
 *    On every future request, checks the 'asid' cookie, loads the session data from disk,
 *    and validates the token by calling the central validator endpoint.
 *
 */
 
 // TODO: Clean up all pending sessions and active sessions after a while
 
 // TODO: Add an optional setting to restrict referrers to the host of CENTRAL_AUTHENTICATION_VALIDATOR_ENDPOINT_URL 

	// Require authentication settings
	$authentication_settings_php_file_fullname = CONTROLLER_SETTINGS_DIR_FULLNAME . '/authentication-settings.php';
	$file_name = $authentication_settings_php_file_fullname; if (!is_file($file_name)) { trigger_error('File not found (' . $file_name .')', E_USER_ERROR); exit(0); }

	require $authentication_settings_php_file_fullname;
	
	// Make sure mandatory settings exist: AUTHENTICATION_ERRORS_LOG_FILE_FULLNAME
	if (! defined('AUTHENTICATION_ERRORS_LOG_FILE_FULLNAME')) { trigger_error('Mandatory definition not found: AUTHENTICATION_ERRORS_LOG_FILE_FULLNAME', E_USER_ERROR); exit(0); }

	// Default values in case not exist in settings:
	
	$authentication_max_time_window_for_activation_sec = 10;
	if (defined('AUTHENTICATION_MAX_TIME_WINDOW_FOR_ACTIVATION_SEC')) { $authentication_max_time_window_for_activation_sec = AUTHENTICATION_MAX_TIME_WINDOW_FOR_ACTIVATION_SEC; }

	$authentication_session_cookie_duration_sec = 3600; //1 Hour
	if (defined('AUTHENTICATION_SESSIONS_COOKIE_DURATION_SEC')) { $authentication_session_cookie_duration_sec = AUTHENTICATION_SESSIONS_COOKIE_DURATION_SEC; }

	/**
	 * Initialize a new authentication session pending to be activated within a short period of time.
	 *
	 * @return string|false
	 */
	function authentication_initSession() {

		if (!defined('AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME')) {
			authentication_writeErrorToLog("authentication_initSession failed: directory constant AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME is not defined");
			return false;
		}
		
		// Validate request method
		if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
			authentication_writeErrorToLog('init_auth_session failed: invalid request method (' . $_SERVER['REQUEST_METHOD'] . ')');
			return false;
		}

		// Read raw input
		$raw_input = file_get_contents('php://input');
		$data = json_decode($raw_input, true);

		if (!is_array($data)) {
			authentication_writeErrorToLog('init_auth_session failed: invalid or missing JSON input');
			return false;
		}

		// Extract fields
		$auth_request_id = $data['auth_request_id'] ?? '';
		$client_ip = $data['client_ip'] ?? '';
		$client_referrer = $data['client_referrer'] ?? '';
		$client_user_agent = $data['client_user_agent'] ?? '';
		$auth_token = $data['auth_token'] ?? '';

		// Strict parameter validation
		if ($auth_request_id === '') {
			authentication_writeErrorToLog("authentication_initSession failed: auth_request_id missing or empty");
			return false;
		}
		if ($client_ip === '') {
			authentication_writeErrorToLog("authentication_initSession failed: client_ip missing or empty");
			return false;
		}
		if ($client_referrer === '') {
			authentication_writeErrorToLog("authentication_initSession failed: client_referrer missing or empty");
			return false;
		}
		if ($client_user_agent === '') {
			authentication_writeErrorToLog("authentication_initSession failed: client_user_agent not set");
			return false;
		}
		if ($auth_token === '') {
			authentication_writeErrorToLog("authentication_initSession failed: auth_token missing or empty");
			return false;
		}

		$session_id = main_getInstanceUid();
		$session_data = [
			'created' => gmdate("d/m/Y H:i:s\te"),
			'auth_request_id' => $auth_request_id,
			'client_ip' => $client_ip,
			'client_referrer' => $client_referrer,
			'client_user_agent' => $client_user_agent,
			'auth_token' => $auth_token,
			'timestamp' => time(),
		];

		if (!is_dir(AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME)) {
			if (! @mkdir(AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME, 0775, true)) {
				authentication_writeErrorToLog("authentication_initSession failed: could not create directory " . AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME);
				return false;
			}
		}

		$session_filename = AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'session_' . $session_id . '.json';
		$json = json_encode($session_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

		if (file_put_contents($session_filename, $json, LOCK_EX) === false) {
			authentication_writeErrorToLog("authentication_initSession failed: could not write session file {$session_filename} (auth_request_id={$auth_request_id})");
			return false;
		}

		return $session_id;
	}

	/**
	 * Activates a pending session if the data is valid (session_id, IP, user agent, and within time limit).
	 * If successful, moves the session to the active directory and sets the session cookie.
	 * Request must be CORS cross-site with a valid HTTP_ORIGIN and HTTP_REFERER.
	 *
	 * @return bool True if session was activated and cookie set, false otherwise.
	 */
	function authentication_activatePendingSession() {
		
		global $authentication_max_time_window_for_activation_sec;
		global $authentication_session_cookie_duration_sec;
		
		if (!defined('AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME') || !defined('AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME')) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: pending or active sessions directory not defined");
			return false;
		}
		
		if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: invalid request method (" . $_SERVER['REQUEST_METHOD'] . ")");
			return false;
		}

		// Check that it's a cross-site CORS request
		if (
			($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') !== 'cross-site' ||
			($_SERVER['HTTP_SEC_FETCH_MODE'] ?? '') !== 'cors'
		) {
			authentication_writeErrorToLog('activate_auth_session failed: expected cross-site CORS request, invalid HTTP_SEC_FETCH_SITE or HTTP_SEC_FETCH_MODE' . " [" . $_SERVER['HTTP_SEC_FETCH_SITE'] ."]. [" . $_SERVER['HTTP_SEC_FETCH_MODE'] ."]");
			return false;
		}

		// Extract headers
		$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
		$client_referrer = $_SERVER['HTTP_REFERER'] ?? '';

		// Validate HTTP_ORIGIN
		if ($origin === '' || !preg_match('#^https://[a-z0-9.-]+$#i', $origin)) {
			authentication_writeErrorToLog('activate_auth_session failed: invalid or missing HTTP_ORIGIN header (value=' . $origin . ')');
			return false;
		}

		// Validate HTTP_REFERER (should start with origin)
		if ($client_referrer === '' || strpos($client_referrer, $origin) !== 0) {
			authentication_writeErrorToLog('activate_auth_session failed: HTTP_REFERER does not match origin (origin=' . $origin . ', client_referrer=' . $client_referrer . ')');
			return false;
		}

		$session_id = $_POST['sid'] ?? '';
		if ($session_id === '') {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: session_id (sid) missing or empty");
			return false;
		}
		if (!preg_match('/^[a-zA-Z0-9_-]+$/', $session_id)) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: invalid session_id format ({$session_id})");
			return false;
		}

		$client_ip = main_getClientIP();
		
		$client_user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
		if ($client_user_agent === '') {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: client_user_agent not set");
			return false;
		}

		$pending_file = AUTHENTICATION_PENDING_SESSIONS_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'session_' . $session_id . '.json';
		if (!file_exists($pending_file)) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: pending session file not found (session_id={$session_id})");
			return false;
		}

		$raw_json = file_get_contents($pending_file);
		if ($raw_json === false) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: could not read pending session file {$pending_file} (session_id={$session_id})");
			return false;
		}

		$data = json_decode($raw_json, true);
		if (!is_array($data)) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: invalid JSON data in {$pending_file} (session_id={$session_id})");
			return false;
		}

		// Validate IP, Referrer, User Agent
		
		if (!isset($data['client_ip'])) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: client_ip not found in session data (session_id={$session_id})");
			return false;
		}
		
		if (!filter_var($data['client_ip'], FILTER_VALIDATE_IP)) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: invalid client_ip ({$data['client_ip']}) in session data (session_id={$session_id})");
			return false;
		}
		
		if ($data['client_ip'] !== $client_ip) {
			$allow_ip_mismatch = defined('AUTHENTICATION_ALLOW_IP_MISMATCH') && AUTHENTICATION_ALLOW_IP_MISMATCH === true;
			if (
				$allow_ip_mismatch &&
				filter_var($data['client_ip'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) &&
				filter_var($client_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
			) {
				// IPv6 to IPv4 mismatch allowed by settings.
				// Central Auth created session for IPv6 client, but this site sees IPv4.
				// Mismatch is expected and allowed — skipping validation.
			} else {
				authentication_writeErrorToLog("authentication_activatePendingSession failed: client_ip mismatch (expected={$data['client_ip']} received={$client_ip}, session_id={$session_id})");
				return false;
			}
		}

		if (!isset($data['client_referrer']) || $data['client_referrer'] !== $client_referrer) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: client_referrer mismatch (expected={$data['client_referrer']} received={$client_referrer}, session_id={$session_id})");
			return false;
		}

		if (!isset($data['client_user_agent']) || $data['client_user_agent'] !== $client_user_agent) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: client_user_agent mismatch (session_id={$session_id})");
			return false;
		}

		// Check time window
		if (!isset($data['timestamp'])) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: timestamp not found in session data (session_id={$session_id})");
			return false;
		}

		$age = time() - $data['timestamp'];
		if ($age > $authentication_max_time_window_for_activation_sec) {
			authentication_writeErrorToLog("authentication_activatePendingSession failed: session expired (created_at={$data['timestamp']}, age={$age}s, session_id={$session_id})");
			return false;
		}

		// Create active session dir if needed
		if (!is_dir(AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME)) {
			if (!@mkdir(AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME, 0775, true)) {
				authentication_writeErrorToLog("authentication_activatePendingSession failed: could not create directory " . AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME);
				return false;
			}
		}

		$active_file = AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'session_' . $session_id . '.json';
		if (!rename($pending_file, $active_file)) {
		authentication_writeErrorToLog("authentication_activatePendingSession failed: could not move session to active directory (pending_file={$pending_file}, active_file={$active_file}, session_id={$session_id})");
			return false;
		}

		// Set cookie (asid stands for 'authentication session id')
		$cookie_set = setcookie('asid', $session_id, [
			'expires' => time() + $authentication_session_cookie_duration_sec,
			'path' => '/',
			'secure' => true,
			'httponly' => true,
			'samesite' => 'None',
		]);

		if (!$cookie_set) {
			authentication_writeErrorToLog("authentication_activatePendingSession warning: session activated but failed to set cookie (session_id={$session_id})");
		}

		return true;
	}

	/**
	* Checks if the request is authenticated.
	* This function is only evaluated once per request.
	*/
	function authentication_isAuthenticated() {
		// Use a static variable to ensure we only evaluate this once per request
		static $is_authenticated = null;
		
		// If authentication was already evaluated, return the result of that evaluation
		if ($is_authenticated !== null) {
			return $is_authenticated;
		}
		
		// If here, it means we need to evaluate the authentication
		
		// Default to false in case of any failure
		$is_authenticated = false;
		
		// Extract session ID from cookie
		$session_id = $_COOKIE['asid'] ?? '';
		if ($session_id === '') {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: asid cookie not set");
			return false;
		}
		if (!preg_match('/^[a-zA-Z0-9_-]+$/', $session_id)) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: invalid session_id format ({$session_id})");
			return false;
		}

		// Read the active session File

		$active_session_file = AUTHENTICATION_ACTIVE_SESSIONS_DIR_FULLNAME . DIRECTORY_SEPARATOR . 'session_' . $session_id . '.json';
		if (!file_exists($active_session_file)) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: active session file not found (session_id={$session_id})");
			return false;
		}
		
		$session_data_raw = file_get_contents($active_session_file);
		if ($session_data_raw === false) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: could not read session file (session_id={$session_id})");
			return false;
		}

		$session_data = json_decode($session_data_raw, true);
		if (!is_array($session_data) || !isset($session_data['auth_token'])) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: invalid session file or missing auth_token (session_id={$session_id})");
			return false;
		}

		$auth_token = $session_data['auth_token'] ?? '';

		// Check if auth settings are available
		if (!defined('CENTRAL_AUTHENTICATION_VALIDATOR_ENDPOINT_URL')) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: CENTRAL_AUTHENTICATION_VALIDATOR_ENDPOINT_URL not defined");
			return false;
		}
		$url = CENTRAL_AUTHENTICATION_VALIDATOR_ENDPOINT_URL;

		// Build auth_info payload
		$auth_info = [
			'client' => [
				'ip' => main_getClientIP(),
				'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
				'protocol' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http',
				'method' => $_SERVER['REQUEST_METHOD'] ?? '',
				'url' => $_SERVER['REQUEST_URI'] ?? '',
				'fetch_dest' => $_SERVER['HTTP_SEC_FETCH_DEST'] ?? '',
				'referer' => $_SERVER['HTTP_REFERER'] ?? '',
			],
			'controller' => [
				'request_id' => main_getInstanceUid(),
				'server_ip' => $_SERVER['SERVER_ADDR'] ?? '',
				'auth_token' => $auth_token,
			],
		];

		$controller_user_agent = 'Controller Authentication (' .
			($_SERVER['HTTP_HOST'] ?? 'na') .
			' ' .
			($_SERVER['SERVER_ADDR'] ?? 'na') .
		')';

		$ch = curl_init();
		curl_setopt_array($ch, [
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_TIMEOUT_MS => 900,
			CURLOPT_CONNECTTIMEOUT_MS => 700,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($auth_info, JSON_UNESCAPED_SLASHES),
			CURLOPT_HTTPHEADER => [
				'User-Agent: ' . $controller_user_agent,
				'Accept: application/json',
				'Content-Type: application/json',
			],
		]);

		$start_time = microtime(true);
		$response = curl_exec($ch);
		$end_time = microtime(true);
		$elapsed_time = round(($end_time - $start_time) * 1000); // in ms

		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$error_no = curl_errno($ch);
		$error_msg = curl_error($ch);

		curl_close($ch);

		if ($error_no !== 0 || $http_code !== 200) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: Error in curl\terror_no={$error_no}\thttp_code={$http_code}\terror_msg={$error_msg}\telapsed_time={$elapsed_time}\tauth_token={$auth_token}\turl={$url}");
			return false;
		}

		// Decode and check JSON
		$response_data = json_decode($response, true);
		if (!is_array($response_data)) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: Invalid JSON response from server\tauth_token={$auth_token}\turl={$url}\tresponse=" . substr($response, 0, 500));
			return false;
		}

		if (!isset($response_data['is_valid'])) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: Invalid JSON response from server: is_valid not found\tauth_token={$auth_token}\turl={$url}\tresponse=" . substr($response, 0, 500));
			return false;
		}

		if (isset($response_data['errors']) && is_array($response_data['errors']) && count($response_data['errors']) > 0) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: Errors in response from server\terrors=[" . implode(', ', $response_data['errors']) . "]\tauth_token={$auth_token}\turl={$url}");
			return false;
		}

		if ($response_data['is_valid'] !== false && $response_data['is_valid'] !== true) {
			authentication_writeErrorToLog("authentication_isAuthenticated failed: Invalid JSON response from server: unexpected is_valid value ({$response_data['is_valid']})\tauth_token={$auth_token}\turl={$url}");
			return false;
		}

		if ($response_data['is_valid'] === true) {
			$is_authenticated = true;
		}
		
		return $is_authenticated;
	}
	
	/**
	 * Writes an authentication-related error to the authentication error log file.
	 */
	function authentication_writeErrorToLog($error_message) {
		$log_entry = main_getExecutionStartTimestampUTC() . "\t[" . main_getInstanceUid() . "]\t" . $error_message;
		logger_writeLogEntry($log_entry, AUTHENTICATION_ERRORS_LOG_FILE_FULLNAME);
	}
?>