<?php
/**
 * 2024-01-19 AWS Cloudfront geo and IP detection added
 * 2023-04-27 major merge of latest changes
 * 2023-01-25 improve the detection of the request scheme
 * 2020-07-20 version 3.0 created
 * 2013-10-24 version 2.0 created
 * 2010-12-20 version 1.0 created
 */

	/**
	 * return the execution start timestamp microseconds as float
	 * see: http://www.php.net/manual/en/function.date.php
	 */
	$g_logger_execution_start_timestamp_microsec_float = microtime(true);
	function logger_getExecutionStartTimestampMicrosecFloat() {
		global $g_logger_execution_start_timestamp_microsec_float;
		return $g_logger_execution_start_timestamp_microsec_float;
	}

	/**
	 * return the execution start timestamp (UTC) as string ("d/m/Y H:i:s e")
	 * see: http://www.php.net/manual/en/function.date.php
	 */
	$g_logger_execution_start_timestamp_utc_string = gmdate("d/m/Y H:i:s\te");
	function logger_getExecutionStartTimestampUTC() {
		global $g_logger_execution_start_timestamp_utc_string;
		return $g_logger_execution_start_timestamp_utc_string;
	}

	/**
	 * return the unique id of this instance
	 */
	$g_logger_instance_uid = str_replace(".", "", uniqid("", TRUE));
	function logger_getInstanceUid() {
		global $g_logger_instance_uid;
		return $g_logger_instance_uid;
	}
	
	/**
	 * return the number of seconds (with a 3 decimal point precision) that has passed since the execution start
	 */
	$g_logger_execution_start_timestamp_microsec_float = microtime(true);
	function logger_getExecutionDurationSec() {
		global $g_logger_execution_start_timestamp_microsec_float;
		return number_format(microtime(true) - $g_logger_execution_start_timestamp_microsec_float, 3);
	}

 
	// these functions are supposed to be defined in the controller main.php
	if (! function_exists("main_getExecutionDurationSec")) { function main_getExecutionDurationSec() { return logger_getExecutionDurationSec(); } }
	if (! function_exists("main_getExecutionStartTimestampUTC")) { function main_getExecutionStartTimestampUTC() { return logger_getExecutionStartTimestampUTC(); } }
	if (! function_exists("main_getInstanceUid")) { function main_getInstanceUid() { return logger_getInstanceUid(); } }
	if (! function_exists("main_getExecutionStartTimestampMicrosecFloat")) { function main_getExecutionStartTimestampMicrosecFloat() { return logger_getExecutionStartTimestampMicrosecFloat(); } }

	/**	
	 * write information about the request into the log file.
	 *
	 * $request_server_data - array with data about the request ($_SERVER for example).
	 * $additional_info_str - additional information to write to log (can be NULL / empty).
	 * $request_log_file_fullname - the full name of the log file.
	 *
	 * log entry format:
	 *
	 * {request_ip_type}\t{request_ip_country_code}\t{timestamp}\t"utc"\t[request_id]\t{request_ip}\t[method]\t[host]\t[uri]\t[HTTP_USER_AGENT=s]\t[HTTP_COOKIE=s]\t[HTTP_REFERER=s]\tMORE={[name=value], ... }\t{additional_info\t}ExecutionDurationSec\t[SERVER_ADDR=ip]\tlogger_writeLogEntry_duration_sec\tlogger_writeLogEntry_number_of_lock_tries
	 *
	 * returns false on failure.
	 */
	function logger_logRequest($request_server_data, $additional_info_str, $request_log_file_fullname) {

		$safe_request_server_data = array();
		if (isset($request_server_data) && is_array($request_server_data)) {
			$safe_request_server_data = $request_server_data;
		}
		
		$safe_additional_info_str = ""; if (isset($additional_info_str) && is_string($additional_info_str)) { $safe_additional_info_str = $additional_info_str; }

		$cf_geo = "cfgeo:";
		if (isset($safe_request_server_data["HTTP_CF_IPCOUNTRY"])) {
			$cf_geo = $cf_geo . $safe_request_server_data["HTTP_CF_IPCOUNTRY"];
		}
		else if (isset($safe_request_server_data["HTTP_CLOUDFRONT_VIEWER_COUNTRY"])) {
			$cf_geo = $cf_geo . $safe_request_server_data["HTTP_CLOUDFRONT_VIEWER_COUNTRY"];
		}

		$cf_ip = "cfip:";
		if (isset($safe_request_server_data["HTTP_CF_CONNECTING_IP"])) {
			$cf_ip = $cf_ip . $safe_request_server_data["HTTP_CF_CONNECTING_IP"];
		}
		else if (isset($safe_request_server_data["HTTP_CLOUDFRONT_VIEWER_ADDRESS"])) {
			$cf_ip = $cf_ip . strtok($safe_request_server_data["HTTP_CLOUDFRONT_VIEWER_ADDRESS"], ':');
		}

		$server_remote_addr = "n-a";
		if (isset($safe_request_server_data["REMOTE_ADDR"])) {
			$server_remote_addr = $safe_request_server_data["REMOTE_ADDR"];
		}

		$request_method	  = "n-a"; if (isset($safe_request_server_data["REQUEST_METHOD"]))			{ $request_method	= $safe_request_server_data["REQUEST_METHOD"];			}
		$request_protocol = "n-a"; if (isset($safe_request_server_data["HTTP_X_FORWARDED_PROTO"]))	{ $request_protocol	= $safe_request_server_data["HTTP_X_FORWARDED_PROTO"];	}
		$request_host	  = "n-a"; if (isset($safe_request_server_data["HTTP_HOST"]))				{ $request_host		= $safe_request_server_data["HTTP_HOST"];				}
		$request_uri	  = "n-a"; if (isset($safe_request_server_data["REQUEST_URI"]))				{ $request_uri		= $safe_request_server_data["REQUEST_URI"];				}
		
		$server_http_user_agent = "HTTP_USER_AGENT"; if (isset($safe_request_server_data["HTTP_USER_AGENT"])) { $server_http_user_agent = "HTTP_USER_AGENT=" . $safe_request_server_data["HTTP_USER_AGENT"]; }
		$server_http_cookie     = "HTTP_COOKIE";     if (isset($safe_request_server_data["HTTP_COOKIE"]))     { $server_http_cookie     = "HTTP_COOKIE="     . $safe_request_server_data["HTTP_COOKIE"];     }
		$server_http_referer    = "HTTP_REFERER";    if (isset($safe_request_server_data["HTTP_REFERER"]))    { $server_http_referer    = "HTTP_REFERER="    . $safe_request_server_data["HTTP_REFERER"];    }

		$log_entry = 
			main_getExecutionStartTimestampUTC() . "\t["
			. main_getInstanceUid() . "]\t"
			. $cf_geo . "\t"
			. $cf_ip . "\t"
			. $server_remote_addr . "\t["
			. $request_method . "]\t["
			. $request_host . "]\t["
			. $request_uri . "]\t["
			. $server_http_user_agent . "]\t["
			. $server_http_cookie . "]\t["
			. $server_http_referer . "]\t["
			. $request_protocol . "]\t["
			. main_getExecutionStartTimestampMicrosecFloat() . "]\t"
			. "MORE=";

		$extra_server_keys = array_diff(array_keys($safe_request_server_data), logger_getServerRequestKeysToIgnore());
		
		foreach ($extra_server_keys as $extra_server_keys) {
			$log_entry = $log_entry . "[" . $extra_server_keys . "=" . $safe_request_server_data["$extra_server_keys"] . "]";
		}

		if (strlen($safe_additional_info_str) > 0) {
			$log_entry = $log_entry . "\t " . $safe_additional_info_str;
		}

		// note: on IIS "SERVER_ADDR" is called "LOCAL_ADDR"
		$safe_server_addr = "n-a"; if (isset($safe_request_server_data["SERVER_ADDR"])) { $safe_server_addr = $safe_request_server_data["SERVER_ADDR"]; } else if (isset($safe_request_server_data["LOCAL_ADDR"])) { $safe_server_addr = $safe_request_server_data["LOCAL_ADDR"]; }
		$log_entry = $log_entry . "\t" . main_getExecutionDurationSec() . "\t[SERVER_ADDR=" . $safe_server_addr . "]";

		return logger_writeLogEntry($log_entry, $request_log_file_fullname);
	}

	/**
	 * write log entry into a log file.
	 *
	 * $log_entry - the entry to write into the log file.
	 * $log_file_fullname - the full name of the log file.
	 *
	 * log entry format:
	 *
	 * $log_entry\tlogger_writeLogEntry_duration_sec\tlogger_writeLogEntry_number_of_lock_tries
	 *
	 * returns false on failure.
	 */
	function logger_writeLogEntry($log_entry, $log_file_fullname) {

		$start_timestamp_float = microtime(true);
		$ret_val = false;

		if ((isset($log_file_fullname) == false) || (is_string($log_file_fullname) == false)) { trigger_error("invalid parameter 'log_file_fullname' (not set)", E_USER_NOTICE); return false; }
		$safe_log_entry = ""; if (isset($log_entry) && is_string($log_entry)) { $safe_log_entry = $log_entry; }
		
		// we tested several methods for implementing a lock on the fwrite which did not work well with 100 requests per second (and even less)
		// the method which seems ok is based on creating a directory, since mkdir() is an atomic operation which returns "false" if the directory already exist
		// if the behaviur of mkdir() changes, this method will not work well...

		// get a name for the lock directory
		$log_file_path_info = pathinfo($log_file_fullname);
		if ((isset($log_file_path_info) == false) || (is_array($log_file_path_info) == false) || (isset($log_file_path_info["dirname"]) == false) || (isset($log_file_path_info["basename"]) == false)) { trigger_error("invalid parameter 'log_file_fullname' (value=" . $log_file_fullname . ")", E_USER_NOTICE); return false; }
		$lock_dir_name = $log_file_path_info["dirname"] . "/__lock__" . $log_file_path_info["basename"] . ".lock";

		$old_umask = umask(0); // we temporary change this so mkdir will function correctly
		
		$count = 0;
		do {
			$count++;
			$lock_obtained = @mkdir($lock_dir_name, 0700, true); // the value of the 3rd parameter is "true" to increase chances mkdir will return false if directory already exist

			// if lock not obtained, sleep for 2 to 15 milliseconds, to avoid collision and CPU load
			if ($lock_obtained != true) { usleep(rand(2000, 15000)); }
		} while (($lock_obtained != true) && ($count < 50)); // stop trying to get a lock after 50 times
		
		umask($old_umask); // restore to original value

		$ret_val = (file_put_contents($log_file_fullname, $safe_log_entry . "\t" . number_format(microtime(true) - $start_timestamp_float, 3) . "\t" . $count . "\t\r\n", FILE_APPEND | LOCK_EX) > 0);

		if ($lock_obtained) {
			rmdir($lock_dir_name); // release the lock
		}

		return $ret_val;
	}

	/**
	 * array of server variables to ignore when logging a request (case sensitive).
	 *
	 * we chose to ignore some server variables and log all the rest, rather than just ask for what we want, this way we can discover new variables.
	 * in this array we put all variables that are not interesting for us, plus all the variables that we write by asking for their value specifically.
	 */
	function logger_getServerRequestKeysToIgnore() {
		return array(
			"_FCGI_X_PIPE_",
			"ALLUSERSPROFILE",
			"APP_POOL_CONFIG",
			"APP_POOL_ID",
			"APPDATA",
			"APPL_MD_PATH",
			"APPL_PHYSICAL_PATH",
			"argc",
			"argv",
			"asl_log",
			"AUTH_PASSWORD",
			"AUTH_TYPE",
			"AUTH_USER",
			"CERT_COOKIE",
			"CERT_FLAGS",
			"CERT_ISSUER",
			"CERT_SERIALNUMBER",
			"CERT_SUBJECT",
			"CLASSPATH",
			"CommonProgramFiles(x86)",
			"CommonProgramFiles",
			"CommonProgramW6432",
			"COMPUTERNAME",
			"ComSpec",
			"COMSPEC",
			"CONTENT_LENGTH",
			"CONTENT_TYPE",
			"CONTEXT_DOCUMENT_ROOT",
			"CONTEXT_PREFIX",
			"CUR_REQUEST_URI",
			"DOCUMENT_ROOT",
			"DOCUMENT_URI",
			"DOMAIN_NAME",
			"DXSDK_DIR",
			"FCGI_ROLE",
			"FP_NO_HOST_CHECK",
			"GATEWAY_INTERFACE",
			"GD_ERROR_DOC",
			"GD_PHP_HANDLER",
			"HOME",
			"HTTP", 	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP"]
			"HTTP_ACCEPT",
			"HTTP_ACCEPT_CHARSET",
			"HTTP_ACCEPT_ENCODING",
			"HTTP_ACCEPT_LANGUAGE",
			"HTTP_CACHE_CONTROL",
			"HTTP_CDN_LOOP",
			"HTTP_CF_CONNECTING_IP",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_CF_CONNECTING_IP"]
			"HTTP_CF_IPCOUNTRY",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_CF_IPCOUNTRY"]
			"HTTP_CF_RAY",
			"HTTP_CF_REQUEST_ID",
			"HTTP_CF_VISITOR",
			"HTTP_CLOUDFRONT_VIEWER_COUNTRY",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_CLOUDFRONT_VIEWER_COUNTRY"]
			"HTTP_CLOUDFRONT_VIEWER_ADDRESS",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_CLOUDFRONT_VIEWER_ADDRESS"]
			"HTTP_CONNECTION",
			"HTTP_CONTENT_LENGTH",
			"HTTP_CONTENT_TYPE",
			"HTTP_COOKIE",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_COOKIE"]
			"HTTP_HOST",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_HOST"]
			"HTTP_IF_NONE_MATCH",
			"HTTP_IF_RANGE",
			"HTTP_KEEP_ALIVE",
			"HTTP_PRAGMA",
			"HTTP_RANGE",
			"HTTP_REFERER",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_REFERER"]
			"HTTP_UA_CPU",
			"HTTP_UPGRADE_INSECURE_REQUESTS",
			"HTTP_USER_AGENT",	// we ignore this key since we ask for its value specifically - see $_SERVER["HTTP_USER_AGENT"]
			"HTTP_X_FORWARDED_PROTO",
			"HTTP_X_HTTPS",
			"HTTP_X_ORIGINAL_URL",	// we ignore this key since we use REQUEST_URI instead for OS compatibility
			"HTTPS",
			"HTTPS_KEYSIZE",
			"HTTPS_SECRETKEYSIZE",
			"HTTPS_SERVER_ISSUER",
			"HTTPS_SERVER_SUBJECT",
			"IIS_UrlRewriteModule",
			"IIS_WasUrlRewritten",
			"INSTANCE_ID",
			"INSTANCE_META_PATH",
			"INSTANCE_NAME",
			"LD_LIBRARY_PATH",
			"LOCAL_ADDR",
			"LOCALAPPDATA",
			"LOGON_USER",
			"LSPHP_ENABLE_USER_INI",
			"MIBDIRS",
			"MYSQL_HOME",
			"NUMBER_OF_PROCESSORS",
			"OPENSSL_CONF",
			"ORIG_PATH_INFO",
			"OS",
			"PARENT_DOCUMENT_ROOT",
			"Path",
			"PATH",
			"PATH_INFO",
			"PATH_TRANSLATED",
			"PATHEXT",
			"PHP_FCGI_CHILDREN",
			"PHP_FCGI_MAX_REQUESTS",
			"PHP_PEAR_SYSCONF_DIR",
			"PHP_SELF",
			"PHPRC",
			"PROCESSOR_ARCHITECTURE",
			"PROCESSOR_ARCHITEW6432",
			"PROCESSOR_IDENTIFIER",
			"PROCESSOR_LEVEL",
			"PROCESSOR_REVISION",
			"ProgramData",
			"ProgramFiles(x86)",
			"ProgramFiles",
			"ProgramW6432",
			"PSModulePath",
			"PUBLIC",
			"PWD",
			"QTJAVA",
			"QUERY_STRING",
			"RAILS_ENV",
			"REAL_DOCUMENT_ROOT",
			"REAL_USERNAME",
			"REDIRECT_DOMAIN_NAME",
			"REDIRECT_dont-vary",
			"REDIRECT_GD_ERROR_DOC",
			"REDIRECT_GD_PHP_HANDLER",
			"REDIRECT_HTTPS",
			"REDIRECT_MIBDIRS",
			"REDIRECT_MYSQL_HOME",
			"REDIRECT_no-gzip",
			"REDIRECT_OPENSSL_CONF",
			"REDIRECT_PARENT_DOCUMENT_ROOT",
			"REDIRECT_PHP_PEAR_SYSCONF_DIR",
			"REDIRECT_PHPRC",
			"REDIRECT_QUERY_STRING",
			"REDIRECT_RAILS_ENV",
			"REDIRECT_REAL_DOCUMENT_ROOT",
			"REDIRECT_REAL_USERNAME",
			"REDIRECT_REDIRECT302",
			"REDIRECT_SCRIPT_URI",
			"REDIRECT_SCRIPT_URL",
			"REDIRECT_SSL_TLS_SNI",
			"REDIRECT_STATUS",
			"REDIRECT_SUBDOMAIN_DOCUMENT_ROOT",
			"REDIRECT_TEMP",
			"REDIRECT_TMP",
			"REDIRECT_TMPDIR",
			"REDIRECT_UNIQUE_ID",
			"REDIRECT_URL",
			"REDIRECT_userlimit_limit",
			"REDIRECT_userlimit_name",
			"REDIRECT_XID",
			"REDIRECT302",
			"REMOTE_ADDR",	// we ignore this key since we ask for its value specifically - see $_SERVER["REMOTE_ADDR"]
			"REMOTE_HOST",
			"REMOTE_PORT",
			"REMOTE_USER",
			"REQUEST_METHOD",	// we ignore this key since we ask for its value specifically - see $_SERVER["REQUEST_METHOD"]
			"REQUEST_SCHEME",
			"REQUEST_TIME",
			"REQUEST_TIME_FLOAT",
			"REQUEST_URI",	// we ignore this key since we ask for its value specifically - see $_SERVER["REQUEST_URI"]
			"SCRIPT_FILENAME",
			"SCRIPT_NAME",
			"SCRIPT_URI",
			"SCRIPT_URL",
			"SERVER_ADDR",	// we ignore this key since we ask for its value specifically - see $_SERVER["SERVER_ADDR"]
			"SERVER_ADMIN",
			"SERVER_NAME",
			"SERVER_PORT",
			"SERVER_PORT_SECURE",
			"SERVER_PROTOCOL",
			"SERVER_SIGNATURE",
			"SERVER_SOFTWARE",
			"SHLVL",
			"SPI",
			"SSL_CIPHER",
			"SSL_CIPHER_ALGKEYSIZE",
			"SSL_CIPHER_EXPORT",
			"SSL_CIPHER_USEKEYSIZE",
			"SSL_CLIENT_VERIFY",
			"SSL_COMPRESS_METHOD",
			"SSL_PROTOCOL",
			"SSL_SECURE_RENEG",
			"SSL_SERVER_A_KEY",
			"SSL_SERVER_A_SIG",
			"SSL_SERVER_I_DN",
			"SSL_SERVER_I_DN_C",
			"SSL_SERVER_I_DN_CN",
			"SSL_SERVER_I_DN_Email",
			"SSL_SERVER_I_DN_L",
			"SSL_SERVER_I_DN_O",
			"SSL_SERVER_I_DN_OU",
			"SSL_SERVER_I_DN_ST",
			"SSL_SERVER_M_SERIAL",
			"SSL_SERVER_M_VERSION",
			"SSL_SERVER_S_DN",
			"SSL_SERVER_S_DN_C",
			"SSL_SERVER_S_DN_CN",
			"SSL_SERVER_S_DN_Email",
			"SSL_SERVER_S_DN_L",
			"SSL_SERVER_S_DN_O",
			"SSL_SERVER_S_DN_OU",
			"SSL_SERVER_S_DN_ST",
			"SSL_SERVER_V_END",
			"SSL_SERVER_V_START",
			"SSL_SESSION_RESUMED",
			"SSL_TLS_SNI",
			"SSL_VERSION_INTERFACE",
			"SSL_VERSION_LIBRARY",
			"SUBDOMAIN_DOCUMENT_ROOT",
			"SystemDrive",
			"SystemRoot",
			"TEMP",
			"TMP",
			"TMPDIR",
			"TZ",
			"UATDATA",
			"UNENCODED_URL",
			"UNIQUE_ID",
			"URL",
			"USER",
			"USERDOMAIN",
			"userlimit_limit",
			"userlimit_name",
			"USERNAME",
			"USERPROFILE",
			"VBOX_INSTALL_PATH",
			"VS100COMNTOOLS",
			"VS110COMNTOOLS",
			"VS90COMNTOOLS",
			"windir",
			"WINDIR",
			"XID",
			
			""	// this is always last to prevent the last comma bug ... ;-)
		);
	}
?>
