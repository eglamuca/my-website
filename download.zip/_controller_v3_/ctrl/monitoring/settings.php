<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * settings for dom controller monitoring
 */

$monitoring_settings = array(
  'critical_time' => 3,
  'exclude_above_time' => 20,
  'mandatory_parameter' => 'ttorigin|campaignid',
  'save_json' => true
  );
