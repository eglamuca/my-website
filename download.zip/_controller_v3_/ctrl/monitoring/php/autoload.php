<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * autoload for dom controller monitoring
 */

@ini_set("display_errors", false);
@ini_set("expose_php", false);
@ini_set("display_errors", false);
@ini_set("display_startup_errors", false);
@ini_set("html_errors", false);
@ini_set("log_errors", true);
@ini_set("error_log", $_SERVER['DOCUMENT_ROOT'] . '/php_errors.log');

require_once 'functions.php';

spl_autoload_register(function ($class_name) {
  include $class_name . '.php';
});

