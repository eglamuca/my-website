<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * MonitoringController class for dom controller monitoring
 */

class MonitoringControlller
{

  public static function getPeriodStats()
  {
    $period = new Period();
    $monitoring = new Monitoring($period);
    return $monitoring->getStats();
  }

  public static function getMonitoringInfo()
  {
    $monitoring_info = new MonitoringInfo();
    return $monitoring_info->getInfo();
  }

}