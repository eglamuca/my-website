<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * MonitoringSettings class for dom controller monitoring
 */

class MonitoringSettings
{
  protected static $settings = null;

  public static function get($param) {
    if (is_null(self::$settings)) {
      self::initiate();
    }
    return self::$settings[$param] ?? null;
  }

  public static function initiate()
  {
    $settings_file = __DIR__ . '/../settings.php';
    if (file_exists($settings_file)) {
      include($settings_file);
    }
    if (isset($monitoring_settings)) {
      self::$settings = $monitoring_settings;
    }
  }

  public static function critical_time()
  {
    return self::get('critical_time') ?? 0;
  }

  public static function exclude_above_time()
  {
      return self::get('exclude_above_time') ?? 0;
  }

  public static function mandatory_parameter()
  {
      return self::get('mandatory_parameter') ?? '';
  }

  public static function save_json()
  {
      return self::get('save_json') ?? false;
  }

}