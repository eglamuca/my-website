<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * MonitoringLogsParser class for dom controller monitoring
 */

class MonitoringLogsParser
{

  private $date;
  private $errors;
  private $user_agent_bots_patterns;

  public function __construct($date)
  {
    $this->setDate($date);
    $this->user_agent_bots_patterns = [
      '~AdsBot~',
      '~Google-Read-Aloud~',
    ];
  }

  private function setDate($date)
  {
    $this->date = $date;
  }

  public function getParsedInitialRequests($date)
  {
    $requests = [];
    $controller_requests_logs_file = $this->getLogsFilePath($date);
    if (!file_exists($controller_requests_logs_file)) {
      throw new Exception('Logs file not found ' . $controller_requests_logs_file);
    }
    $mandatory_parameter = MonitoringSettings::get('mandatory_parameter') ?? '';
    if (false !== ($handle = @fopen($controller_requests_logs_file, "r"))) {
      while (($buffer = @fgets($handle)) !== false) {
        $line_array = preg_split("/[\t]/", $buffer);
        if (false === $line_array) continue;
        if (14 > count($line_array)) continue;
        $url = trim($line_array[8], "[]"); // index 8 = request uri
        $request_with_mandatory_parameter_pattern = '~(' . $mandatory_parameter . ')=([^]&]+)~';
        if (!preg_match($request_with_mandatory_parameter_pattern, $url)) {
          continue;
        }
        $user_agent = str_replace('HTTP_USER_AGENT=', '', trim($line_array[9], "[]"));
        foreach ($this->user_agent_bots_patterns as $user_agent_bots_pattern) {
          if (preg_match($user_agent_bots_pattern, $user_agent)) {
            continue 2;
          }
        }
        $request_timestamp = trim($line_array[13], "[]"); // index 13 = request initial timestamp
        $controller_id = trim($line_array[2], "[]"); // index 2 = controller id
        $ip = trim(str_replace('cfip:', '', $line_array[4]));
        $requests[$controller_id] = array(
          'ip' => $ip,
          'url' => $url,
          'initial_timestamp' => $request_timestamp,
          'dom_loaded_timestamp' => null,
          'real_lp' => null,
        );
      }
    }
    fclose($handle);
    return $requests;
  }

  public function getParsedFinalRequests($date)
  {
    $requests = [];
    $controller_requests_logs_file = $this->getLogsFilePath($date);
    if (!file_exists($controller_requests_logs_file)) {
      return $requests;
    }
    if (false !== ($handle = @fopen($controller_requests_logs_file, "r"))) {
      while (($buffer = @fgets($handle)) !== false) {
        $line_array = preg_split("/[\t]/", $buffer);
        if (false === $line_array) continue;
        if (14 > count($line_array)) continue;
        $url = trim($line_array[8], "[]"); // index 8 = request uri
        $api_request_pattern = '~/api/event/(onload/)?\?controller_id=([^]&]+)(&timestamp=([^]&]+))?(&lp=([^]&]+))?~';
        
        if (preg_match($api_request_pattern, $url, $matches)) {
          $controller_id = $matches[2] ?? '';
          if ($controller_id) {
            if (isset($requests[$controller_id])) {
              $requests[$controller_id]['duplicated']++;
            } else {
              $real_lp = $matches[6] ?? 'n/a';
              $request_timestamp = trim($line_array[13], "[]"); // index 13 = request initial timestamp
              $requests[$controller_id]['dom_loaded_timestamp'] = $request_timestamp;
              $requests[$controller_id]['real_lp'] = $real_lp;
              $requests[$controller_id]['duplicated'] = 0;
            }
          }
        }
      }
    }
    fclose($handle);
    return $requests;
  }

  public function parseLogsRequests()
  {
    $requests = [];
    try {
      $requests = $this->getParsedInitialRequests($this->date);
      $final_requests = $this->getParsedFinalRequests($this->date);
      $next_date = date('Y-m-d', strtotime($this->date . " +1 day"));
      $final_requests += $this->getParsedFinalRequests($next_date);
      foreach ($requests as $controller_id => $request) {
        if (empty($request['dom_loaded_timestamp'])) {
          if (isset($final_requests[$controller_id])) {
            $requests[$controller_id]['dom_loaded_timestamp'] = $final_requests[$controller_id]['dom_loaded_timestamp'];
            $requests[$controller_id]['real_lp'] = $final_requests[$controller_id]['real_lp'];
            $requests[$controller_id]['duplicated'] = $final_requests[$controller_id]['duplicated'];
          }
        }
      }
    } catch (Exception $e) {
      $this->errors[] = $e->getMessage();
    }
    return ['requests' => $requests, 'errors' => $this->errors];
  }

  function getLogsFilePath($date)
  {
    $date = date('Ymd', strtotime($date));
    return realpath("../../../") . "/logs/$date--requests-log.txt";
  }
}
