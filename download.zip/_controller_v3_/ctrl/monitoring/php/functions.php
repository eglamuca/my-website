<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * common functions for dom controller monitoring
 */

if (!function_exists('echo_json')) {
  function echo_json($json)
  {
    header('Content-Type: application/json');
    echo $json;
  }
}

if (!function_exists('abort')) {
  function abort($number, $message = '')
  {
    $n = (int)$number;
    $responses = [
      '404' => 'Not Found',
      '403' => 'Forbidden',
    ];
    if (isset($responses[$n])) {
      $msg = $message ? $message : $responses[$n];
      header("HTTP/1.1 $n $msg");
      exit();
    }
  }
}

