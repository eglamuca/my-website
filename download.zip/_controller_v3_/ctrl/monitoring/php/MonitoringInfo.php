<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * MonitoringInfo class for dom controller monitoring
 */

class MonitoringInfo
{

  public function getInfo()
  {
    $domain = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '';
    $domain = preg_replace(['/^www./', '/^dev./', '/^prep./'], '', $domain);
    $mandatory_parameter = MonitoringSettings::mandatory_parameter();
    $critical_time = MonitoringSettings::critical_time();
    $exclude_above_time = MonitoringSettings::exclude_above_time();
    return [
      'domain' => $domain,
      'mandatory_parameter' => $mandatory_parameter,
      'critical_time' => $critical_time,
      'exclude_above_time' => $exclude_above_time,
    ];
  }

}