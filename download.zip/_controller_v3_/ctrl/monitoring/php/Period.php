<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * Period class for dom controller monitoring
 */

class Period
{
  public $start_date;
  public $end_date;

  public function __construct()
  {
    $this->setDates();
  }

  private function setDates()
  {
    $this->start_date = $_REQUEST['start_date'] ?? $_REQUEST['date'] ?? $this->yesterdayDate();
    $this->end_date = $_REQUEST['end_date'] ?? $_REQUEST['date'] ?? $this->yesterdayDate();
    $this->start_date = date('Y-m-d' , strtotime($this->start_date));
    $this->end_date = date('Y-m-d' , strtotime($this->end_date));
  }

  private function yesterdayDate()
  {
    return date('Y-m-d' , strtotime('yesterday'));
  }

}