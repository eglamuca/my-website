<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * Monitoring class for dom controller monitoring
 */

class Monitoring
{
  private $period;
  private $errors;


  public function __construct($period)
  {
    $this->errors = [];
    $this->setPeriod($period);
  }

  private function setPeriod($period)
  {
    if ($period->start_date > $period->end_date) {
      $this->errors[] = 'Wrong period dates: start date must be before end date';
    }
    $this->period = $period;
  }

  public function getStats()
  {
    $daily_stats = [];
    for (
      $date = $this->period->start_date;
      $date <= $this->period->end_date;
      $date = date('Y-m-d', strtotime("$date +1 day"))
    ) {
      $daily_stats[$date] = $this->getDailyStats($date);
    }

    $stats = $this->calculatePeriodStats($daily_stats);

    $stats = $this->formatPeriodStats($stats);
    return [
      'period' => [
        'start_date' => $this->period->start_date,
        'end_date' => $this->period->end_date
      ],
      'stats' => $stats,
      'errors' => $this->errors
    ];
  }

  private function calculatePeriodStats($daily_stats)
  {
    $period_stats = [];
    foreach ($daily_stats as $date => $stats) {
      foreach ($stats as $lp => $lp_stats) {
        if (!isset($period_stats[$lp])) {
          $period_stats[$lp] = [];
        }
        foreach ($lp_stats as $real_lp => $real_lp_stats) {
          if (!isset($period_stats[$lp][$real_lp])) {
            $period_stats[$lp][$real_lp] = $this->emptyStats();
            $period_stats[$lp][$real_lp]['min'] = $real_lp_stats['min'];
          }
          $period_stats[$lp][$real_lp] = $this->aggregateStats($real_lp_stats, $period_stats[$lp][$real_lp]);
        }
      }
    }
    return $period_stats;
  }

  private function emptyStats()
  {
    return [
      'total_number' => 0,
      'min' => 0,
      'max' => 0,
      'slow' => 0,
      'normal' => 0,
      'finished' => 0,
      'not_finished' => 0,
      'total_finished_time' => 0,
      'total_normal_time' => 0,
      'normal_avg' => 0,
      'total_avg' => 0,
      'duplicated' => 0
    ];
  }

  function getSmallestNonZero($a, $b) {
    if ($a != 0 && ($b == 0 || $a < $b)) {
        return $a;
    } elseif ($b != 0) {
        return $b;
    } else {
        return 0; // Both values are zero
    }
  }

  private function aggregateStats($s1, $s2)
  {

    $s1Min = (float)$s1['min'];
    $s2Min = (float)$s2['min'];
    $sMin = $this->getSmallestNonZero($s1Min, $s2Min);

    return [
      'total_number' => $s1['total_number'] + $s2['total_number'],
      'min' => $sMin,
      'max' => max($s1['max'], $s2['max']),
      'slow' => $s1['slow'] + $s2['slow'],
      'normal' => $s1['normal'] + $s2['normal'],
      'finished' => $s1['finished'] + $s2['finished'],
      'not_finished' => $s1['not_finished'] + $s2['not_finished'],
      'total_finished_time' => $s1['total_finished_time'] + $s2['total_finished_time'],
      'total_normal_time' => $s1['total_normal_time'] + $s2['total_normal_time'],
      'normal_avg' => $this->calculateAvg(($s1['total_normal_time'] + $s2['total_normal_time']), ($s1['normal'] + $s2['normal'])),
      'total_avg' => $this->calculateAvg(($s1['total_finished_time'] + $s2['total_finished_time']), ($s1['finished'] + $s2['finished'])),
      'duplicated' => $s1['duplicated'] + $s2['duplicated']
    ];
  }

  private function formatPeriodStats($period_stats)
  {
    foreach ($period_stats as $lp => $lp_stats) {
      foreach ($lp_stats as $real_lp => $real_lp_stats) {
        $period_stats[$lp][$real_lp] = $this->formatStats($real_lp_stats);
      }
    }
    return $period_stats;
  }

  private function formatStats($s)
  {
    return [
      'total_number' => number_format($s['total_number'], 0, '.', ''),
      'min' => number_format($s['min'], 4, '.', ''),
      'max' => number_format($s['max'], 4, '.', ''),
      'slow' => number_format($s['slow'], 0, '.', ''),
      'normal' => number_format($s['normal'], 0, '.', ''),
      'finished' => number_format($s['finished'], 0, '.', ''),
      'not_finished' => number_format($s['not_finished'], 0, '.', ''),
      'total_finished_time' => number_format($s['total_finished_time'], 4, '.', ''),
      'total_normal_time' => number_format($s['total_normal_time'], 4, '.', ''),
      'normal_avg' => number_format($s['normal_avg'], 4, '.', ''),
      'total_avg' => number_format($s['total_avg'], 4, '.', ''),
      'duplicated' => number_format($s['duplicated'], 0, '.', ''),
    ];
  }

  private function calculateAvg($sum, $number)
  {
    if ($number == 0) {
      return 0;
    }
    return $sum / $number;
  }

  private function getDailyStats($date)
  {
    $stats = $this->getDailyStatsFromJsonFile($date);

    if (empty($stats)) {
      $parser = new MonitoringLogsParser($date);
      $parsed = $parser->parseLogsRequests();

      if (!empty($parsed['errors'])) {
        array_push($this->errors, ...$parsed['errors']);
      }

      $stats = $this->calculateDailyStats($parsed['requests']);

      $this->saveDailyStatsToJsonFile($date, $stats);
    }

    return $stats;
  }

  private function getDailyStatsFromJsonFile($date)
  {
    $stats = [];
    if ($file = realpath($this->getDailyStatsJsonFilePath($date))) {
      $json = file_get_contents($file);
      $stats = json_decode($json, true);
    }
    return $stats;
  }

  private function saveDailyStatsToJsonFile($date, $stats)
  {
    $save_json = MonitoringSettings::save_json();
    $today = date('Y-m-d');
    if ($save_json && !empty($stats) && $date < $today) {
      $json_stats = json_encode($stats, JSON_UNESCAPED_SLASHES);
      $result = file_put_contents($this->getDailyStatsJsonFilePath($date), $json_stats);
    }
  }

  private function getDailyStatsJsonFilePath($date)
  {
    return realpath("../") . "/stats/$date.json";
  }


  private function calculateDailyStats($requests)
  {
    $stats = [];
    $url_grouped_requests = [];

    foreach ($requests as $request) {

      $dom_loaded_time = 0;
      if (isset($request['dom_loaded_timestamp'])) {
        $dom_loaded_time = floatval($request['dom_loaded_timestamp']) - floatval($request['initial_timestamp']);
        $dom_loaded_time = number_format($dom_loaded_time, 4, '.', '');
      }
      $url = $request['url'];
      if (false !== strpos($url, '?')) {
        $url = substr($url, 0, strpos($url, '?'));
      }
      $real_lp = $request['real_lp'] ?? 'n/a';
      $url_grouped_requests[$url][$real_lp][] = [
        'dom_loaded_time' => $dom_loaded_time,
        'duplicated' => $request['duplicated'] ?? 0,
      ];
    }



    foreach ($url_grouped_requests as $url => $url_requests) {

      foreach ($url_requests as $real_lp => $real_lp_requests) {

        $stats[$url][$real_lp] = $this->calculateStats($real_lp_requests);

      }
    }

    return $stats;
  }

  private function calculateStats($requests)
  {

    $duplicationsInt = $this->calculateDuplications($requests);
    $countRequests = count($requests);
    $countFinished = $this->countFinishedRequests($requests);

    return [
      'total_number' => count($requests) + (int)$duplicationsInt,
      'min' => $this->calculateMinTime($requests),
      'max' => $this->calculateMaxTime($requests),
      'avg' => $this->calculateAvgTime($requests),
      'slow' => $this->countSlowRequests($requests),
      'normal' => $this->countNormalRequests($requests),
      'finished' => $this->countFinishedRequests($requests),
      'not_finished' => $countRequests - $countFinished,
      'total_finished_time' => $this->aggregateTotalFinishedTime($requests),
      'total_normal_time' => $this->aggregateTotalNormalTime($requests),
      'duplicated' => $duplicationsInt
    ];
  }

  private function calculateDuplications($requests)
  {
    $totalDuplications = 0;

    foreach ($requests as $request) {
      $totalDuplications += (int)$request['duplicated'];
    }

    return $totalDuplications;
  }

  private function calculateMinTime($requests)
  {
    $min_time = null;

    foreach ($requests as $request) {

      $time = floatval($request['dom_loaded_time']);

      if($time > 0) {
        if(!isset($min_time) || $min_time > $time) {
          $min_time = $time;
        }
      }
     
    }

    return number_format($min_time, 4, '.', '');
  }


  private function calculateMaxTime($requests)
  {
    $max_time = 0;
    foreach ($requests as $request) {
      $time = floatval($request['dom_loaded_time']);
      if ($max_time < $time) {
        $max_time = $time;
      }
    }
    return number_format($max_time, 4, '.', '');
  }

  private function calculateAvgTime($requests)
  {
    if (0 == count($requests)) {
      $avg_time = 0;
    } else {
      $time_sum = array_reduce($requests, function ($carry, $item) {
        return $carry + floatval($item['dom_loaded_time']);
      }, 0.0);
      $avg_time = $time_sum / count($requests);
    }
    return number_format($avg_time, 4, '.', '');
  }

  private function countSlowRequests($requests)
  {
    $critical_time = MonitoringSettings::critical_time();
    $slow_requests = 0;
    foreach ($requests as $request) {
      if ($critical_time && $request['dom_loaded_time'] > $critical_time) {
        $slow_requests += 1;
      }
    }
    return $slow_requests;
  }

  private function countNormalRequests($requests)
  {
    $exclude_above_time = MonitoringSettings::exclude_above_time();
    $normal_requests = 0;
    foreach ($requests as $request) {
      if ($request['dom_loaded_time'] > 0 && $request['dom_loaded_time'] < $exclude_above_time) {
        $normal_requests += 1;
      }
    }
    return $normal_requests;
  }

  private function countFinishedRequests($requests)
  {
    $finished_requests = 0;
    foreach ($requests as $request) {
      if ($request['dom_loaded_time'] > 0) {
        $finished_requests += 1;
      }
    }
    return $finished_requests;
  }

  private function aggregateTotalFinishedTime($requests)
  {
    $finished_requests_time = 0;
    foreach ($requests as $request) {
      if ($request['dom_loaded_time'] > 0) {
        $finished_requests_time += $request['dom_loaded_time'];
      }
    }
    return number_format($finished_requests_time, 4, '.', '');;
  }

  private function aggregateTotalNormalTime($requests)
  {
    $exclude_above_time = MonitoringSettings::exclude_above_time();
    $normal_requests_time = 0;
    foreach ($requests as $request) {
      if ($request['dom_loaded_time'] > 0 && $request['dom_loaded_time'] < $exclude_above_time) {
        $normal_requests_time += $request['dom_loaded_time'];
      }
    }
    return number_format($normal_requests_time, 4, '.', '');
  }
}
