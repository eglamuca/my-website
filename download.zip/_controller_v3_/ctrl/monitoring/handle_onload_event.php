<?php
/**
 * 2023-04-27 major merge of latest changes
 *
 * onload event is reported here
 */
$newTimestamp = 'na';
if (function_exists("main_getExecutionStartTimestampMicrosecFloat")) {
  $newTimestamp = main_getExecutionStartTimestampMicrosecFloat();
}

echo json_encode([
  'message' => 'OK',
  'data' => [
    'timestamp' => "$newTimestamp",
  ],
]);

exit(0);
?>