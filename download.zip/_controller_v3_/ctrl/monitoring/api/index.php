<?php
/**
 * 2024-05-02 dom controller monitoring updated
 *
 * api entry point for dom controller monitoring
 */

require_once '../php/autoload.php';

$http_origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$http_host = $_SERVER['HTTP_HOST'] ?? '';
$request_scheme = $_SERVER['HTTP_X_FORWARDED_PROTO'] ?? $_SERVER['REQUEST_SCHEME'] ?? 'https';

$allowed_domains = array(
  "${request_scheme}://${http_host}",
);

if (empty($http_host) || empty($http_origin) || !in_array($http_origin, $allowed_domains))
{
  abort(403);
}

header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 240");

header("Access-Control-Allow-Origin: $http_origin");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Access-Control-Allow-Headers, Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$action = $_POST['action'] ?? '';

if ($action == 'getPeriodStats') {
  $result = MonitoringControlller::getPeriodStats();
} elseif ($action == 'getMonitoringInfo') {
  $result = MonitoringControlller::getMonitoringInfo();
} else {
  abort(404);
}

$json = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
echo_json($json);
