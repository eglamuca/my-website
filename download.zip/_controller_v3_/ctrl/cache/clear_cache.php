<?php
/**
 * 2024-09-09 clear cache
 */

$current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$parsed_url = parse_url($current_url);
$domain = $parsed_url['host'];

$url = 'https://api.drtraffic.org/cloudflare/purge-cache-public';
$data = array(
    'domain' => $domain,
    'token' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6ItCU0LXQvdGMINC_0YDQvtGI0LXQuyAtINCyINC60LDRgNC80LDQvdC1INC00L7Qu9C70LDRgCIsImlhdCI6MTUxNjIzOTAyMn0.rXgO1mrasuas0IXb2eZPdeuN6PslK6tFE-jF3H7zfzU'
);

$ch = curl_init($url);

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);

if ($response === false) {
    $error = curl_error($ch);
    curl_close($ch);
    die('Curl error: ' . $error);
}

curl_close($ch);

// Output the response
echo $response;
?>