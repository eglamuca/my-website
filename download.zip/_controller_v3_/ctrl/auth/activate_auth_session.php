<?php
/**
 * 2025-03-26 created
 *
 * activate_auth_session.php
 *
 * Handles client browser requests to activate a pending authentication session.
 *
 * This request originates from a page inside the central authentication server,
 * running in the user's browser. The browser makes a cross-site POST request
 * to this endpoint, including credentials and origin headers.
 *
 * If valid, returns a JSON {"is_active": true}.
 * If invalid, returns HTTP 404 without error details (to avoid leaking info).
 *
 */

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';

if ($origin !== '' && strpos(CENTRAL_AUTHENTICATION_VALIDATOR_ENDPOINT_URL, $origin) === 0) {
  header('Access-Control-Allow-Origin: ' . $origin);
  header('Access-Control-Allow-Credentials: true');
  header('Access-Control-Allow-Methods: GET, POST');
  header('Vary: Origin');
}

$is_active = authentication_activatePendingSession();
if (!$is_active) {
  http_response_code(404);
  exit();
}

// All good: the request origin is the central authentication server
// therefore we allow the browser to handle this response for that origin
header('Content-Type: application/json');

echo json_encode(['is_active' => true]);
exit();

?>