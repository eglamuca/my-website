<?php
/**
 * 2025-03-26 created
 *
 * init_auth_session.php
 *
 * Handles session initialization requests from the central authentication server (server to server request).
 *
 * If valid, returns a JSON response with the session ID.
 * If invalid, returns HTTP 404 without error details (to avoid leaking info).
 */

$session_id = authentication_initSession();
if ($session_id === false) {
  http_response_code(404);
  exit();
}

header('Content-Type: application/json');
echo json_encode(['session_id' => $session_id]);
exit();

?>