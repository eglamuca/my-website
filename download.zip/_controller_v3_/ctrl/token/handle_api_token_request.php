<?php
/**
 * 2025-02-18 sensitive pages restrictions added
 * Handling of requests from zomdak.com
 * Entry point is set in controller_settings.php getPHPAliasUrlsArray() function
 * Ping request is needed to verify that entry point is functional and accessible
 * Other requests add cookie and make redirect to URL if all expected parameters are passed otherwise return error
 */

$auth_token_domain = defined('CONTROLLER_AUTH_TOKEN_DOMAIN') ? CONTROLLER_AUTH_TOKEN_DOMAIN : '';

if (!empty($auth_token_domain)) {

  $allowed_domains = array(
    "https://${auth_token_domain}",
    "https://www.${auth_token_domain}",
  );

  $http_origin = $_SERVER['HTTP_ORIGIN'] ?? '';

  if (in_array($http_origin, $allowed_domains)) {
    header("Access-Control-Allow-Origin: $http_origin");
  }

}

header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Access-Control-Allow-Headers, Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
header("Cache-Control: no-store, no-cache, must-revalidate, maxSHIFT_SETTINGS_FILE_NAME-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


$action = $_POST["action"] ?? '';

if ($action == "ping") {
  $result = array('status' => 'success');
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($result);
  exit();
}

$token = $_GET['token'] ?? '';
$urlEncoded = $_GET['url'] ?? '';
$url = base64_decode($urlEncoded);

if (empty($token)) {
  $error = 'Empty token';
} elseif (empty($url)) {
  $error = 'Empty url';
} elseif (false === filter_var($url, FILTER_VALIDATE_URL)) {
  $error = 'Invalid URL';
} else {
  $domain = $_SERVER['HTTP_HOST'] ?? '';
  $domain = preg_replace('/^www./', '', $domain);
  $auth_token_cookie = defined('CONTROLLER_AUTH_TOKEN_COOKIE') ? CONTROLLER_AUTH_TOKEN_COOKIE : '';
  if (!empty($auth_token_cookie)) {
    setcookie($auth_token_cookie, "$token", time() + 3600*24*30, "/", ".$domain");
  }
?>
<script>
    window.location.replace("<?php echo $url; ?>");
</script>
<?php
exit();
}

header('HTTP/1.0 403 Forbidden');
$result = array ('status' => 'error', 'message' => $error);
echo json_encode($result);
exit();

