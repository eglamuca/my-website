<?php
/**
 * 2023-04-27 major merge of latest changes
 *
 * tool to move all log files to archive folder and zip them
 */

	echo "<h1>Log Zipper</h1><p>start (id=" . main_getInstanceUid() . ")</p>";
	
	// make sure archive directory exists
	$archive_directory = CONTROLLER_LOGS_DIR_FULLNAME . "/archive";
	if (! is_dir($archive_directory)) {
		if (true !== mkdir($archive_directory, 0700, true)) {
			echo "<h2>ERROR</h2><p>archive directory not found (" . $archive_directory . ")</p>";
			exit(0);
		}
	}

	// list the files that we want to zip
	//
	// yyyymmdd--requests-log.txt
	// yyyymmdd--response-errors-log.txt

	$log_files_to_archive = array();
	$files_to_skip = array();

	$dir_name = CONTROLLER_LOGS_DIR_FULLNAME;
	if ((@is_dir($dir_name)) && (($handle = @opendir($dir_name)) !== false)) {
		while (($entry = @readdir($handle)) !== false) {
			if ((CONTROLLER_LOG_FILES_DATE_PREFIX . "requests-log.txt" == $entry) || (CONTROLLER_LOG_FILES_DATE_PREFIX . "response-errors-log.txt" == $entry)) {
				// skip the current log files
				$files_to_skip[] = $entry;
			}
			else {
				$entry_postfix = substr($entry, strlen(CONTROLLER_LOG_FILES_DATE_PREFIX) - 2);
				if (("--requests-log.txt" == $entry_postfix) || ("--response-errors-log.txt" == $entry_postfix)) {
					$log_files_to_archive[] = $entry;
				}
				else if (($entry != ".") && ($entry != "..")) {
					$files_to_skip[] = $entry;
				}
			}
		}
		@closedir($handle);
	}

	if (0 >= count($log_files_to_archive)) {
		echo "<p>No log files to zip.</p>";
	}
	else {
		echo "<h2>Files to zip:</h2><ul><li>" . implode("</li><li>", $log_files_to_archive) . "</li></ul>";
	}
	
	if (0 >= count($files_to_skip)) {
		echo "<p>No log files to skip.</p>";
	}
	else {
		echo "<h2>Skipping these files:</h2><ul><li>" . implode("</li><li>", $files_to_skip) . "</li></ul>";
	}

	if (0 >= count($log_files_to_archive)) {
		exit(0);
	}

	$log_name = $log_files_to_archive[0];
    echo "<h2>Zipping file: " . $log_name . "</h2>";

	if (true !== rename(CONTROLLER_LOGS_DIR_FULLNAME . "/" . $log_name, CONTROLLER_LOGS_DIR_FULLNAME . "/archive/" . $log_name)) {
		// error !!!
		echo "<h2>ERROR</h2><p>rename failed</p>";
		exit(0);
	}
	
	$zip_name = substr($log_name, 0, -4) . ".zip";
	chdir(CONTROLLER_LOGS_DIR_FULLNAME . "/archive");chdir(".");
	$cmd="zip -b ../../tmp -j -v -r " . $zip_name . " " . $log_name;

	echo "<p>cmd=" . $cmd . "</p>";

	// use popen to execute a unix command pipeline
	// and grab the stdout as a php stream
	// (you can use proc_open instead if you need to 
	// control the input of the pipeline too)
	$fp = popen($cmd, 'r');

	// pick a bufsize that makes you happy (64k may be a bit too big).
	$bufsize = 65535;
	$buff = '';
	while( !feof($fp) ) {
	   $buff = fread($fp, $bufsize);
	   echo $buff;
	}
	pclose($fp);

	echo "<p>end (duration=" . main_getExecutionDurationSec() . " sec.)</p>";
?>	
<h2>Refresh</h2>
<p id="refresh"></p>
<script>	
	var counter = 6;
	var interval = setInterval(function() {
		if(0 < counter) {
			--counter;
		}
		else {
			clearInterval(interval);
			 location.reload();
		}
		document.getElementById("refresh").innerHTML="refresh in "+counter+" sec";
	}, 1000);
</script>
<button type="button" onclick="clearInterval(interval);">Stop!</button>
