<?php
/**
 * 2023-04-27 major merge of latest changes
 *
 * tool to search for all .htaccess files and change their permission
 */
	if (! isset($_SERVER["REQUEST_METHOD"])) { exit(0); }
	
	$htaccess_files_fullname = array();
	function populate_htaccess_files_fullname($dir_name) {
		global $htaccess_files_fullname;
		if ((@is_dir($dir_name)) && (($handle = @opendir($dir_name)) !== false)) {
			while (($entry = @readdir($handle)) !== false) {
				if ($entry == ".htaccess") {
					$htaccess_files_fullname[] = $dir_name . "/.htaccess";
				}
				else if (($entry != ".") && ($entry != "..")) {
					populate_htaccess_files_fullname($dir_name . "/" . $entry);
				}
			}
			@closedir($handle);
    }
	}
	populate_htaccess_files_fullname(WEBSITE_ROOT_DIR_FULLNAME);
	
	if (strcmp($_SERVER["REQUEST_METHOD"], "POST") == 0) {
		foreach ($htaccess_files_fullname as $htaccess_filename) {
			if ($htaccess_filename != WEBSITE_ROOT_DIR_FULLNAME . "/_controller_/templates/_document_root_/.htaccess") {
				@chmod($htaccess_filename, 0444);
			}
		}
		header("HTTP/1.1 301 Moved Permanently");
		header("Location: " . parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH) . "?chmod_done=" . main_getInstanceUid());
		exit(0);
	}

?>
<html>
	<head>
		<style type="text/css">
* { padding:0; margin:0; }
#main-container { width:600px; margin: 10px auto; background-color:#D0D0D0; }
#header { text-align:center; }
#output-container { float:left; width:590px; margin:5px; background-color:#F0F0F0; }
#output-container table { margin:10px auto; }
#footer { clear:both; text-align:center; font:12px "Courier New", monospace; }
.input-field { width:130px; }
.result-field { width:130px; font:14px "Courier New", monospace; }
.button { width:100px; }
		</style>
	</head>
	<body>
		<div id="main-container">
			<div id="header">
				<h1>Welcome</h1>
			</div>
			<div id="output-container">
				<table>
					<tr><td><u>location</u></td><td>&nbsp;&nbsp;&nbsp;</td><td><u>size [perm]</u></td></tr>
					<?php
						foreach ($htaccess_files_fullname as $htaccess_filename) {
							if (
								(($htaccess_filesize  = @filesize($htaccess_filename))  === false) ||
								(($htaccess_fileperms = @fileperms($htaccess_filename)) === false)
							) {
								echo "<tr><td>" . substr($htaccess_filename, strlen(WEBSITE_ROOT_DIR_FULLNAME)) . "</td><td>&nbsp;&nbsp;&nbsp;</td><td><b style='color:red;'>Error</b></td></tr>";
							}
							else {
								echo "<tr><td>" . substr($htaccess_filename, strlen(WEBSITE_ROOT_DIR_FULLNAME)) . "</td><td>&nbsp;&nbsp;&nbsp;</td><td>" . $htaccess_filesize . " bytes [" . substr(sprintf('%o', $htaccess_fileperms), -4) . "]</td></tr>";
							}
						}
					?>
				</table>
				<div style="text-align:center; margin:0 auto 0 auto;"><form action="<?php echo parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH) . "?chmod_do=" . main_getInstanceUid(); ?>" method="post"><input type="submit" class="button" value="chmod()"></form></div>
				<br />
			</div>
			<div id="footer">
			<?php
				echo "execution start time: [" . main_getExecutionStartTimestampUTC() . "] duration (sec): [" . main_getExecutionDurationSec() . "]";
			?>
			</div>
		</div>
	</body>
</html>
