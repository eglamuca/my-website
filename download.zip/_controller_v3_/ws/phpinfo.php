<?php 
/**
 * 2023-04-27 major merge of latest changes
 *
 * tool to output PHP Information
 */
phpinfo();
?>
