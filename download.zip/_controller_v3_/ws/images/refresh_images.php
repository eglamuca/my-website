<?php
/**
 * 2025-03-05 renaming images
 *
 *  List of made image renaming or errors occurred
 *  If HTML file couldn't be renamed due to file permissions images are not renamed
 *  If required image files not found HTML and image files are not renamed
 *  If refreshing finished with errors 'Refresh Images' button is inactive
 */

// Direct access prohibited
if (!defined('CONTROLLER_REFRESH_IMAGES_DIRECTORY')) {
  http_response_code(404);
  exit(0);
}

$htmlFiles = [];
$resourceFiles = [];
$newResourceFiles = [];
$resourceFilesErrors = [];
$htmlBackupFiles = [];
$htmlFilesReplacements = [];
$htmlFilesErrors = [];

$baseDir = WEBSITE_ROOT_DIR_FULLNAME;
$ignoreDirs = ['_controller_v3_', '_shift_', 'assets'];

processDirectory($baseDir, $ignoreDirs,$htmlFiles);

d($htmlFiles);

foreach ($htmlFiles as $htmlFilePath) {
  processHtmlFile($htmlFilePath, $resourceFiles);
}

d($resourceFiles);

foreach ($resourceFiles as $resourceFile) {
  $newResourceFilePath = newResourceFilePath($resourceFile->resourceFilePath, $newResourceFiles);
  $htmlFilesReplacements[$resourceFile->resourceLinkFileFullPath][$resourceFile->resourceLink]
    = str_replace(WEBSITE_ROOT_DIR_FULLNAME, '', $newResourceFilePath);
}

d($newResourceFiles);

foreach ($newResourceFiles as $oldResourceFilePath => $newResourceFilePath) {
  if (!file_exists($oldResourceFilePath)) {
    $resourceFilesErrors[$oldResourceFilePath] = 'File not found';
  }
}

if (empty($resourceFilesErrors)) {

  foreach ($htmlFilesReplacements as $htmlFilePath => $replacements) {
    $backupFile = backupFile($htmlFilePath);
    $htmlBackupFiles[$htmlFilePath] = $backupFile;
    if (!file_exists($backupFile)) {
      $htmlFilesErrors[$htmlFilePath] = 'Backup not created';
    }
  }

  if (empty($htmlFilesErrors)) {

    foreach ($htmlFilesReplacements as $htmlFilePath => $replacements) {
      $content = file_get_contents($htmlFilePath);
      if (empty($content)) {
        $htmlFilesErrors[$htmlFilePath] = 'File not available';
      } else {
        foreach ($replacements as $old => $new) {
          $content = str_replace($old, $new, $content);
        }
        $result = file_put_contents($htmlFilePath, $content);
        if (empty($result)) {
          $htmlFilesErrors[$htmlFilePath] = 'File not modified';
        }
      }
    }

    if (empty($resourceFilesErrors)) {
      if (empty($htmlFilesErrors)) {
        foreach ($newResourceFiles as $oldResourceFilePath => $newResourceFilePath) {
          if (file_exists($oldResourceFilePath)) {
            if (isOriginalResource($oldResourceFilePath)) {
              copy($oldResourceFilePath, $newResourceFilePath);
            } else {
              rename($oldResourceFilePath, $newResourceFilePath);
            }
          } else {
            $resourceFilesErrors[$oldResourceFilePath] = 'File not found';
          }
        }
      }
    }

  }

}

d($htmlFilesErrors);

foreach ($newResourceFiles as $oldResourceFilePath => $newResourceFilePath) {
  if (!file_exists($newResourceFilePath)) {
    if (!file_exists($oldResourceFilePath)) {
      $resourceFilesErrors[$oldResourceFilePath] = 'File not found';
    } else {
      $resourceFilesErrors[$oldResourceFilePath] = 'File was not renamed';
    }
  }
}

d($resourceFilesErrors);

d($newResourceFiles);

d($htmlFilesReplacements);

d($htmlFilesErrors);

$disabled = (empty($resourceFilesErrors)) ? '' : 'disabled';
$error = (empty($resourceFilesErrors)) ? '' : 'error'

// Generate HTML Report
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Website Images Refresh Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f4f4f4; }
        .section { margin-bottom: 40px; }
        .error { color: red; }

        /* Button Styles */
        .refresh-button {
            background-color: #4CAF50; /* Green background */
            color: white; /* White text */
            padding: 10px 20px; /* Padding */
            border: none; /* Remove borders */
            border-radius: 5px; /* Rounded corners */
            font-size: 16px; /* Font size */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s ease; /* Smooth hover effect */
        }

        /* Hover Effect */
        .refresh-button:hover {
            background-color: #45a049; /* Darker green on hover */
        }

        /* Disabled Button */
        .refresh-button:disabled {
            background-color: #ccc; /* Gray background */
            color: #666; /* Gray text */
            cursor: not-allowed; /* Disabled cursor */
        }

        /* Button Focus */
        .refresh-button:focus {
            outline: 2px solid #3e8e41; /* Focus outline */
            outline-offset: 2px;
        }

    </style>
</head>
<body>
    <h1>Website Images Refresh Report</h1>

    <div class="section">
        <h2>New HTML Files</h2>
        <table>
            <thead>
                <tr>
                    <th>HTML File</th>
                    <th>Backup File</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($htmlBackupFiles as $filePath => $backupFile): ?>
                <tr>
                    <td title="<?php echo listReplacements($filePath, $htmlFilesReplacements); ?>"><?php echo htmlspecialchars($filePath); ?></td>
                    <td><?php echo htmlspecialchars($backupFile); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>New Images</h2>
        <table>
            <thead>
                <tr>
                    <th>Old Image Path</th>
                    <th>New Image Path</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($newResourceFiles as $oldResourceFilePath => $newResourceFilePath): ?>
                <tr>
                    <td><?php echo htmlspecialchars($oldResourceFilePath); ?></td>
                    <td><?php echo htmlspecialchars($newResourceFilePath); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2 class="<?php echo $error; ?>">Errors Encountered</h2>
        <?php if (empty($htmlFilesErrors) && empty($resourceFilesErrors)): ?>
            <p>No errors encountered during the process.</p>
        <?php endif; ?>
        <?php if (!empty($htmlFilesErrors)): ?>
            <ul>
                <?php foreach ($htmlFilesErrors as $file => $error): ?>
                <li class="error"><?php echo htmlspecialchars($file); ?> - <?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
      <?php if (!empty($resourceFilesErrors)): ?>
        <ul>
          <?php foreach ($resourceFilesErrors as $file => $error): ?>
            <li class="error"><?php echo htmlspecialchars($file); ?> - <?php echo htmlspecialchars($error); ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>

    <button id="backButton" class="refresh-button">Back</button>
    <button id="refreshButton" class="refresh-button" <?php echo $disabled; ?>>Refresh Images</button>

    <script>

      const refreshButton = document.getElementById('refreshButton');
      // Add a click event listener to reload the page with the action=refresh parameter
      refreshButton.addEventListener('click', () => {
        const url = new URL(window.location.href);
        url.searchParams.set('action', 'refresh');
        window.location.href = url.toString();
      });

      const backButton = document.getElementById('backButton');
      // Add a click event listener to reload the page without the action=refresh parameter
      backButton.addEventListener('click', () => {
        const url = new URL(window.location.href);
        url.searchParams.delete('action'); // Remove the 'action' parameter
        window.location.href = url.toString(); // Reload the page without the parameter
      });

    </script>

</body>
</html>

