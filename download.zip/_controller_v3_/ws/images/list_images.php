<?php
/**
 * 2025-03-05 renaming images
 *
 * List of current HTML files and images
 * If any required image file was not found refreshing is impossible - 'Refresh Images' button is inactive
 */

// Direct access prohibited
if (!defined('CONTROLLER_REFRESH_IMAGES_DIRECTORY')) {
  http_response_code(404);
  exit(0);
}

$htmlFiles = [];
$resourceFiles = [];
$resourceFilesErrors = [];

$baseDir = WEBSITE_ROOT_DIR_FULLNAME;
$ignoreDirs = ['_controller_v3_', '_shift_', 'assets'];

processDirectory($baseDir, $ignoreDirs,$htmlFiles);

sort($htmlFiles);

d($htmlFiles);

foreach ($htmlFiles as $htmlFilePath) {
  processHtmlFile($htmlFilePath, $resourceFiles);
}

ksort($resourceFiles);

d($resourceFiles);

foreach ($resourceFiles as $resourceFile) {
  $oldResourceFilePath = $resourceFile->resourceFilePath;
  if (!file_exists($oldResourceFilePath)) {
    $resourceFilesErrors[$oldResourceFilePath] = 'File not found';
  }
}

d($resourceFilesErrors);

$disabled = (empty($resourceFilesErrors)) ? '' : 'disabled';
$error = (empty($resourceFilesErrors)) ? '' : 'error'
// Generate HTML Report
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Website Images</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2 { color: #333; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f4f4f4; }
        .section { margin-bottom: 40px; }
        .error { color: red; }

        /* Button Styles */
        .refresh-button {
            background-color: #4CAF50; /* Green background */
            color: white; /* White text */
            padding: 10px 20px; /* Padding */
            border: none; /* Remove borders */
            border-radius: 5px; /* Rounded corners */
            font-size: 16px; /* Font size */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s ease; /* Smooth hover effect */
        }

        /* Hover Effect */
        .refresh-button:hover {
            background-color: #45a049; /* Darker green on hover */
        }

        /* Disabled Button */
        .refresh-button:disabled {
            background-color: #ccc; /* Gray background */
            color: #666; /* Gray text */
            cursor: not-allowed; /* Disabled cursor */
        }

        /* Button Focus */
        .refresh-button:focus {
            outline: 2px solid #3e8e41; /* Focus outline */
            outline-offset: 2px;
        }

    </style>
</head>
<body>
    <h1>Website Images</h1>

    <div class="section">
        <h2>HTML Files</h2>
        <table>
            <thead>
                <tr>
                    <th>HTML File Full Path</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($htmlFiles as $htmlFilePath): ?>
                <tr>
                    <td><?php echo htmlspecialchars($htmlFilePath); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>Images</h2>
        <table>
            <thead>
                <tr>
                    <th>Image Full Path</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($resourceFiles as $resourceFile): ?>
                <tr>
                    <td><?php echo htmlspecialchars($resourceFile->resourceFilePath); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2 class="<?php echo $error; ?>">Errors</h2>
        <?php if (empty($resourceFilesErrors)): ?>
            <p>No errors detected.</p>
        <?php endif; ?>
        <?php if (!empty($resourceFilesErrors)): ?>
          <ul>
            <?php foreach ($resourceFilesErrors as $file => $error): ?>
              <li class="error"><?php echo htmlspecialchars($file); ?> - <?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
    </div>

    <button id="refreshButton" class="refresh-button" <?php echo $disabled; ?>>Refresh Images</button>

    <script>
      const refreshButton = document.getElementById('refreshButton');
      // Add a click event listener to reload the page with the action=refresh parameter
      refreshButton.addEventListener('click', () => {
        const url = new URL(window.location.href);
        url.searchParams.set('action', 'refresh');
        window.location.href = url.toString();
      });
    </script>

</body>
</html>

