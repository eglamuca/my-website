<?php
/**
 * 2025-03-05 renaming images
 *
 * Entry point for making unique names for images in HTML code
 */

if (!defined('WEBSITE_ROOT_DIR_FULLNAME')) {
  trigger_error("Constant WEBSITE_ROOT_DIR_FULLNAME is not defined", E_USER_ERROR);
  exit(0);
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

define('CONTROLLER_REFRESH_IMAGES_DIRECTORY', __DIR__);
define('REFRESH_IMAGES_PHP_FILE', CONTROLLER_REFRESH_IMAGES_DIRECTORY . '/refresh_images.php' );
define('LIST_IMAGES_PHP_FILE', CONTROLLER_REFRESH_IMAGES_DIRECTORY . '/list_images.php' );
define('REFRESH_IMAGES_FUNCTIONS_PHP_FILE', CONTROLLER_REFRESH_IMAGES_DIRECTORY . '/functions.php' );

if (!file_exists(REFRESH_IMAGES_PHP_FILE)) {
  trigger_error("File not found: " . REFRESH_IMAGES_PHP_FILE, E_USER_ERROR);
  exit(0);
}

if (!file_exists(LIST_IMAGES_PHP_FILE)) {
  trigger_error("File not found: " . LIST_IMAGES_PHP_FILE, E_USER_ERROR);
  exit(0);
}

if (!file_exists(REFRESH_IMAGES_FUNCTIONS_PHP_FILE)) {
  trigger_error("File not found: " . REFRESH_IMAGES_FUNCTIONS_PHP_FILE, E_USER_ERROR);
  exit(0);
}

if (file_exists(WEBSITE_ROOT_DIR_FULLNAME . '/wp-config.php')) {
  print "This function doesn't work for WordPress websites";
  exit(0);
}

require_once REFRESH_IMAGES_FUNCTIONS_PHP_FILE;

$action = $_GET["action"] ?? '';

if ($action == "refresh") {
 require_once REFRESH_IMAGES_PHP_FILE;
} else {
  require_once LIST_IMAGES_PHP_FILE;
}

exit(0);

