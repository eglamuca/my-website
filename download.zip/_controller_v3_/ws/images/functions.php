<?php
/**
 * 2025-03-05 renaming images
 *
 */

// Direct access prohibited
if (!defined('CONTROLLER_REFRESH_IMAGES_DIRECTORY')) {
  http_response_code(404);
  exit(0);
}

function processDirectory($dirPath, $ignoreDirs, &$htmlFiles)
{
  // Skip ignored directories
  foreach ($ignoreDirs as $ignoreDir) {
    if (strpos($dirPath, $ignoreDir) !== false) {
      return;
    }
  }

  // Open directory
  if ($handle = opendir($dirPath)) {
    while (false !== ($entry = readdir($handle))) {
      if ($entry != "." && $entry != "..") {
        $fullPath = $dirPath . DIRECTORY_SEPARATOR . $entry;

        // If it's a directory, process recursively
        if (is_dir($fullPath)) {
          processDirectory($fullPath, $ignoreDirs,$htmlFiles);
        }
        // If it's index.php, process file
        elseif (isHtmlFile($fullPath)) {
          $htmlFiles[] = $fullPath;
        }
      }
    }
    closedir($handle);
  }
}

function isHtmlFile($filePath)
{
  $pathInfo = pathinfo($filePath);
  $ext = $pathInfo['extension'] ?? '';
  $filename = $pathInfo['filename'] ?? '';
  $dirname = $pathInfo['dirname'] ?? '';
  $dir = basename($dirname);
  $file = $filename;
  if (!empty($ext)) {
    $file .= '.' . $ext;
  }

  if ($file == 'index.php') {
    return true;
  }
  if ($ext == 'php' && in_array($dir, ['php', 'parts'])) {
    $content = file_get_contents($filePath);
    if (preg_match('/<img[^>]+(["\'])([^"\']+\.(jpg|jpeg|png|gif|webp|svg))\1/', $content)) {
      return true;
    }
    if (preg_match('/url\(([^)]+\.(jpg|jpeg|png|gif|webp|svg))\)/', $content)) {
      return true;
    }
  }
  return false;
}

function processHtmlFile($filePath, &$resourceFiles)
{
  // Read the content of the file
  $content = file_get_contents($filePath);

  // Find all image names in the file
  preg_match_all('/<img[^>]+(["\'])([^"\']+\.(jpg|jpeg|png|gif|webp|svg))\1/', $content, $matches);
  if (count($matches[2]) > 0) {
    foreach ($matches[2] as $resourceLink) {
      if (preg_match('/<\?php/', $resourceLink)) {
        continue;
      }
      if (preg_match('/<\?=/', $resourceLink)) {
        continue;
      }
      $resource = new WebsiteResource($resourceLink, $filePath);
      $resourceFilePath = $resource->resourceFilePath;
      if (!isset($resourceFiles[$resourceFilePath])) {
        $resourceFiles[$resourceFilePath] = $resource;
      }
    }
  }

  // Find all background image names in the file
  preg_match_all('/url\(([^)]+\.(jpg|jpeg|png|gif|webp|svg))\)/', $content, $matches);
  if (count($matches[1]) > 0) {
    foreach ($matches[1] as $resourceLink) {
      if (preg_match('/<\?php/', $resourceLink)) {
        continue;
      }
      if (preg_match('/<\?=/', $resourceLink)) {
        continue;
      }
      $resource = new WebsiteResource($resourceLink, $filePath);
      $resourceFilePath = $resource->resourceFilePath;
      if (!isset($resourceFiles[$resourceFilePath])) {
        $resourceFiles[$resourceFilePath] = $resource;
      }
    }
  }


}


// Function to back up files before modifying them
function backupFile($filePath)
{
  $backupIndex = 1;
  $backupFileName = $filePath . '.' . $backupIndex . '.orig';
  while (file_exists($backupFileName)) {
    $backupIndex++;
    $backupFileName = $filePath . '.' . $backupIndex . '.orig';
  }
  copy($filePath, $backupFileName);
  return $backupFileName;
}

function newResourceFilePath($oldResourceFilePath, &$newResourceFiles) {
  if (!isset($newResourceFiles[$oldResourceFilePath])) {
    $uniqId = uniqid('', true);
    $pathInfo = pathinfo($oldResourceFilePath);
    $ext = $pathInfo['extension'];
    $filename = $pathInfo['filename'];
    $dirname = $pathInfo['dirname'];
    if (preg_match("/_([a-z0-9]{14}\.[0-9]{8})$/", $filename, $matches)) {
      $oldUniqId = $matches[1];
      $filename = str_replace("_{$oldUniqId}", '', $filename);
    }
    $filename .= "_{$uniqId}";
    $newResourceFilePath = $dirname . DIRECTORY_SEPARATOR . $filename . '.' . $ext;
    $newResourceFiles[$oldResourceFilePath] = $newResourceFilePath;
  }
  return $newResourceFiles[$oldResourceFilePath];
}

function isOriginalResource($oldResourceFilePath) {
  $pathInfo = pathinfo($oldResourceFilePath);
  $filename = $pathInfo['filename'];
  return !preg_match("/_([a-z0-9]{14}\.[0-9]{8})$/", $filename);
}

Class WebsiteResource {

  public $resourceLink;
  public $resourceLinkFileFullPath;
  public $resourceFileName;
  public $resourceFileDirectoryRelativePath;
  public $resourceFileDirectoryAbsolutePath;
  public $resourceFilePath;
  public $rootDirectory;

  public function __construct($resourceLink, $resourceLinkFileFullPath)
  {
    $this->rootDirectory = WEBSITE_ROOT_DIR_FULLNAME;
    $this->resourceLink = $resourceLink;
    $this->resourceLinkFileFullPath = $resourceLinkFileFullPath;
    $this->guessFileName();
    $this->guessFileDirectory();
    $this->buildFilePath();
  }

  private function guessFileName()
  {
    if (preg_match('~(.*)/([^/]+)$~', $this->resourceLink, $matches)) {
      $this->resourceFileName = $matches[2];
    } else {
      $this->resourceFileName = $this->resourceLink;
    }
  }

  private function guessFileDirectory()
  {
    $this->resourceFileDirectoryRelativePath = '';
    if (preg_match('~(.*)/([^/]+)$~', $this->resourceLink, $matches)) {
      $this->resourceFileDirectoryRelativePath = $matches[1];
    }
    $entryPointDirectory = pathinfo($this->resourceLinkFileFullPath, PATHINFO_DIRNAME);
    $entryPointDirectoryPath = str_replace($this->rootDirectory, '', $entryPointDirectory);
    $entryPointDirectoryPath = trim($entryPointDirectoryPath, '/');
    $relativeFileDirectoryPath = trim($this->resourceFileDirectoryRelativePath, '/');
    $this->resourceFileDirectoryAbsolutePath = getAbsolutePathFromRelativePath($relativeFileDirectoryPath, $entryPointDirectoryPath);
  }

  private function buildFilePath()
  {
    $this->resourceFilePath = $this->rootDirectory;
    if (!empty($this->resourceFileDirectoryAbsolutePath)) {
      $this->resourceFilePath .= DIRECTORY_SEPARATOR . $this->resourceFileDirectoryAbsolutePath;
    }
    $this->resourceFilePath .= DIRECTORY_SEPARATOR . $this->resourceFileName;
  }

}

function getAbsolutePathFromRelativePath($relativeFileDirectoryPath, $entryPointDirectoryPath) {
  $rdirs = explode('/', $relativeFileDirectoryPath);
  $epdirs = explode('/', $entryPointDirectoryPath);

  if (in_array('..', $rdirs)) {
    $reversedEntryPointDirs = array_reverse($epdirs);
    foreach ($rdirs as $k => $rdir) {
      if ('..' == $rdir) {
        unset($rdirs[$k]);
        unset($reversedEntryPointDirs[$k]);
      }
    }
    $epdirs = array_reverse($reversedEntryPointDirs);
    $dirs = array_merge($epdirs, $rdirs);
  } elseif ($rdirs[0] == '.') {
    array_shift($rdirs);
    $dirs = array_merge($epdirs, $rdirs);
  } else {
    $dirs = $rdirs;
  }
  $path = implode('/', $dirs);
  return $path;
}

function d($item) {
  if (isset($_GET['debug'])) {
    print '<pre>';
    print_r($item);
    print '</pre>';
  }
}
function listReplacements($filePath, $htmlFilesReplacements) {
  $list = '';
  if (isset($htmlFilesReplacements[$filePath])) {
    foreach ($htmlFilesReplacements[$filePath] as $old => $new) {
      $list .= $old . ' : ' . $new . PHP_EOL;
    }
  }
  return $list;
}
